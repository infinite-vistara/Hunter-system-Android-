package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SportsMartialArts
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.LevelUpOverlay
import com.example.ui.components.SystemWelcomeBanner
import com.example.ui.screens.CalendarHistoryScreen
import com.example.ui.screens.DailyCheckInScreen
import com.example.ui.screens.DailyStackScreen
import com.example.ui.screens.MartialArtsCodexScreen
import com.example.ui.screens.MobilityCodexScreen
import com.example.ui.screens.NotificationsSettingsScreen
import com.example.ui.screens.StatusWindowScreen
import com.example.ui.screens.TopicRouletteScreen
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.HunterViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: HunterViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                HunterApp(viewModel = viewModel)
            }
        }
    }
}

@Composable
fun HunterApp(viewModel: HunterViewModel) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()
    val levelUpDialog by viewModel.levelUpDialog.collectAsStateWithLifecycle()

    val showBottomNav = state.currentScreen in listOf(
        AppScreen.STATUS_WINDOW,
        AppScreen.DAILY_CHECK_IN,
        AppScreen.MARTIAL_ARTS_CODEX,
        AppScreen.CALENDAR_HISTORY,
        AppScreen.NOTIFICATIONS_SETTINGS
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = SystemBackground,
        bottomBar = {
            if (showBottomNav) {
                SystemBottomNavigation(
                    currentScreen = state.currentScreen,
                    onNavigate = { viewModel.navigateTo(it) }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Crossfade(
                targetState = state.currentScreen,
                animationSpec = androidx.compose.animation.core.tween(durationMillis = 150),
                label = "screen_transition"
            ) { screen ->
                when (screen) {
                    AppScreen.STATUS_WINDOW -> StatusWindowScreen(state = state, viewModel = viewModel)
                    AppScreen.DAILY_CHECK_IN -> DailyCheckInScreen(state = state, viewModel = viewModel)
                    AppScreen.CALENDAR_HISTORY -> CalendarHistoryScreen(state = state, viewModel = viewModel)
                    AppScreen.MARTIAL_ARTS_CODEX -> MartialArtsCodexScreen(state = state, viewModel = viewModel)
                    AppScreen.MOBILITY_CODEX -> MobilityCodexScreen(state = state, viewModel = viewModel)
                    AppScreen.DAILY_STACK_GUIDE -> DailyStackScreen(state = state, viewModel = viewModel)
                    AppScreen.TOPIC_ROULETTE -> TopicRouletteScreen(state = state, viewModel = viewModel)
                    AppScreen.NOTIFICATIONS_SETTINGS -> NotificationsSettingsScreen(state = state, viewModel = viewModel)
                }
            }

            // Awakening Level Up Modal Overlay
            levelUpDialog?.let { (level, rankTier) ->
                LevelUpOverlay(
                    visible = true,
                    newLevel = level,
                    rankTier = rankTier,
                    onDismiss = { viewModel.dismissLevelUpDialog() }
                )
            }

            // Short 1-2s System Welcome Banner
            var showWelcome by remember { mutableStateOf(true) }
            if (showWelcome) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                ) {
                    SystemWelcomeBanner(
                        userName = state.hunterName,
                        onDismiss = { showWelcome = false }
                    )
                }
            }
        }
    }
}

@Composable
fun SystemBottomNavigation(
    currentScreen: AppScreen,
    onNavigate: (AppScreen) -> Unit
) {
    NavigationBar(
        modifier = Modifier
            .fillMaxWidth()
            .border(width = 1.dp, color = BorderSubtle)
            .windowInsetsPadding(WindowInsets.navigationBars),
        containerColor = Color(0xFF090E1D),
        contentColor = ElectricBlue
    ) {
        NavigationBarItem(
            selected = currentScreen == AppScreen.STATUS_WINDOW,
            onClick = { onNavigate(AppScreen.STATUS_WINDOW) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Shield,
                    contentDescription = "Status Window",
                    modifier = Modifier.size(20.dp)
                )
            },
            label = {
                Text(
                    text = "STATUS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue,
                indicatorColor = Color(0xFF14284A),
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_status")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.DAILY_CHECK_IN,
            onClick = { onNavigate(AppScreen.DAILY_CHECK_IN) },
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Daily Quests",
                    modifier = Modifier.size(20.dp)
                )
            },
            label = {
                Text(
                    text = "QUESTS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue,
                indicatorColor = Color(0xFF14284A),
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_quests")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.MARTIAL_ARTS_CODEX,
            onClick = { onNavigate(AppScreen.MARTIAL_ARTS_CODEX) },
            icon = {
                Icon(
                    imageVector = Icons.Default.SportsMartialArts,
                    contentDescription = "Martial Codex",
                    modifier = Modifier.size(20.dp)
                )
            },
            label = {
                Text(
                    text = "CODEX",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue,
                indicatorColor = Color(0xFF14284A),
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_codex")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.CALENDAR_HISTORY,
            onClick = { onNavigate(AppScreen.CALENDAR_HISTORY) },
            icon = {
                Icon(
                    imageVector = Icons.Default.CalendarMonth,
                    contentDescription = "Archive",
                    modifier = Modifier.size(20.dp)
                )
            },
            label = {
                Text(
                    text = "LOGS",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue,
                indicatorColor = Color(0xFF14284A),
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_history")
        )

        NavigationBarItem(
            selected = currentScreen == AppScreen.NOTIFICATIONS_SETTINGS,
            onClick = { onNavigate(AppScreen.NOTIFICATIONS_SETTINGS) },
            icon = {
                Icon(
                    imageVector = Icons.Default.Notifications,
                    contentDescription = "Settings",
                    modifier = Modifier.size(20.dp)
                )
            },
            label = {
                Text(
                    text = "SYSTEM",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp
                )
            },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = ElectricBlue,
                selectedTextColor = ElectricBlue,
                indicatorColor = Color(0xFF14284A),
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            ),
            modifier = Modifier.testTag("nav_item_settings")
        )
    }
}
