package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.DailyLog
import com.example.data.model.Habit
import com.example.data.model.RewardClaim
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Habit::class, DailyLog::class, RewardClaim::class],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun habitDao(): HabitDao
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun rewardClaimDao(): RewardClaimDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "hunter_system.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialHabits(database.habitDao())
                    }
                }
            }
        }

        suspend fun populateInitialHabits(habitDao: HabitDao) {
            val defaultHabits = listOf(
                Habit(
                    id = 1,
                    name = "Sleep Integrity (7.5 hrs min)",
                    stat = "VIT",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "22:30",
                    isReminderEnabled = true,
                    orderIndex = 1
                ),
                Habit(
                    id = 2,
                    name = "Circadian Reset (Sunlight AM + Cold PM)",
                    stat = "VIT",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "07:30",
                    isReminderEnabled = true,
                    orderIndex = 2
                ),
                Habit(
                    id = 3,
                    name = "Mobility & Stretching Flow",
                    stat = "STR",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "12:00",
                    isReminderEnabled = true,
                    orderIndex = 3
                ),
                Habit(
                    id = 4,
                    name = "Martial Arts Practice (Rank Path)",
                    stat = "AGI",
                    frequency = "2x_week",
                    xpPerCheck = 10,
                    reminderTime = "18:00",
                    isReminderEnabled = true,
                    reminderDays = "WED,SAT",
                    orderIndex = 4
                ),
                Habit(
                    id = 5,
                    name = "Book Mastery / Deep Study (1 hr)",
                    stat = "INT",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "09:00",
                    isReminderEnabled = true,
                    orderIndex = 5
                ),
                Habit(
                    id = 6,
                    name = "College Record Work (1 hr)",
                    stat = "INT",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "14:00",
                    isReminderEnabled = true,
                    orderIndex = 6
                ),
                Habit(
                    id = 7,
                    name = "Money Hustle / Income Work (1 hr)",
                    stat = "INT",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "16:00",
                    isReminderEnabled = true,
                    orderIndex = 7
                ),
                Habit(
                    id = 8,
                    name = "Digital Discipline (No Mindless Scroll)",
                    stat = "PER",
                    frequency = "daily",
                    xpPerCheck = 10,
                    reminderTime = "21:00",
                    isReminderEnabled = true,
                    orderIndex = 8
                ),
                Habit(
                    id = 9,
                    name = "Apex Protocol (Peak Output & Limit Break)",
                    stat = "STR",
                    frequency = "daily",
                    xpPerCheck = 15,
                    reminderTime = "06:30",
                    isReminderEnabled = true,
                    orderIndex = 9
                )
            )
            habitDao.insertAll(defaultHabits)
        }
    }
}
