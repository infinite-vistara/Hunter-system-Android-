package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.DailyLog
import kotlinx.coroutines.flow.Flow

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs WHERE date = :date")
    fun getLogsForDate(date: String): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs WHERE completed = 1")
    fun getAllCompletedLogs(): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs")
    fun getAllLogs(): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs")
    suspend fun getAllLogsList(): List<DailyLog>

    @Query("SELECT * FROM daily_logs WHERE date >= :startDate AND date <= :endDate")
    fun getLogsBetween(startDate: String, endDate: String): Flow<List<DailyLog>>

    @Query("SELECT * FROM daily_logs WHERE date = :date AND habitId = :habitId LIMIT 1")
    suspend fun getLog(date: String, habitId: Long): DailyLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: DailyLog)

    @Query("DELETE FROM daily_logs WHERE date = :date AND habitId = :habitId")
    suspend fun deleteLog(date: String, habitId: Long)

    @Query("DELETE FROM daily_logs")
    suspend fun clearAll()
}
