package com.example.data.local

import com.example.data.model.DailyLog
import com.example.data.model.Habit
import com.example.data.model.RewardClaim
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class HunterRepository(
    private val habitDao: HabitDao,
    private val dailyLogDao: DailyLogDao,
    private val rewardClaimDao: RewardClaimDao
) {
    val activeHabits: Flow<List<Habit>> = habitDao.getActiveHabits()
    val allHabits: Flow<List<Habit>> = habitDao.getAllHabits()
    val allCompletedLogs: Flow<List<DailyLog>> = dailyLogDao.getAllCompletedLogs()
    val allLogs: Flow<List<DailyLog>> = dailyLogDao.getAllLogs()

    fun getLogsForDate(date: String): Flow<List<DailyLog>> = dailyLogDao.getLogsForDate(date)

    fun observeClaimForDate(date: String): Flow<RewardClaim?> = rewardClaimDao.observeClaimForDate(date)

    suspend fun getClaimForDate(date: String): RewardClaim? = withContext(Dispatchers.IO) {
        rewardClaimDao.getClaimForDate(date)
    }

    suspend fun saveRewardClaim(claim: RewardClaim) = withContext(Dispatchers.IO) {
        rewardClaimDao.insert(claim)
    }

    suspend fun setHabitCompletion(date: String, habitId: Long, completed: Boolean) = withContext(Dispatchers.IO) {
        val existing = dailyLogDao.getLog(date, habitId)
        if (existing == null) {
            dailyLogDao.insertOrUpdate(
                DailyLog(
                    date = date,
                    habitId = habitId,
                    completed = completed,
                    updatedAt = System.currentTimeMillis()
                )
            )
        } else {
            dailyLogDao.insertOrUpdate(
                existing.copy(completed = completed, updatedAt = System.currentTimeMillis())
            )
        }
    }

    suspend fun saveHabit(habit: Habit): Long = withContext(Dispatchers.IO) {
        if (habit.id == 0L) {
            habitDao.insert(habit)
        } else {
            habitDao.update(habit)
            habit.id
        }
    }

    suspend fun deleteHabit(habit: Habit) = withContext(Dispatchers.IO) {
        habitDao.delete(habit)
    }

    suspend fun countTier3ClaimsThisWeek(): Int = withContext(Dispatchers.IO) {
        val calendar = Calendar.getInstance()
        calendar.firstDayOfWeek = Calendar.MONDAY
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)
        calendar.set(Calendar.SECOND, 0)
        calendar.set(Calendar.MILLISECOND, 0)
        val startOfWeek = calendar.timeInMillis
        rewardClaimDao.countTier3ClaimsSince(startOfWeek)
    }

    suspend fun checkAndSeedInitialHabits() = withContext(Dispatchers.IO) {
        if (habitDao.getHabitCount() == 0) {
            AppDatabase.populateInitialHabits(habitDao)
        } else {
            val all = habitDao.getAllHabitsList()
            val hasApex = all.any { it.name.contains("Apex Protocol", ignoreCase = true) }
            if (!hasApex) {
                val maxOrder = all.maxOfOrNull { it.orderIndex } ?: 8
                habitDao.insert(
                    Habit(
                        name = "Apex Protocol (Peak Output & Limit Break)",
                        stat = "STR",
                        frequency = "daily",
                        xpPerCheck = 15,
                        reminderTime = "06:30",
                        isReminderEnabled = true,
                        orderIndex = maxOrder + 1
                    )
                )
            }
        }
    }

    suspend fun exportDataAsJson(): String = withContext(Dispatchers.IO) {
        val root = JSONObject()
        root.put("version", 1)
        root.put("exportedAt", System.currentTimeMillis())
        
        val habitsList = habitDao.getAllHabitsList()
        val habitsArray = JSONArray()
        for (h in habitsList) {
            val hObj = JSONObject().apply {
                put("id", h.id)
                put("name", h.name)
                put("stat", h.stat)
                put("frequency", h.frequency)
                put("xpPerCheck", h.xpPerCheck)
                put("isActive", h.isActive)
                put("reminderTime", h.reminderTime)
                put("isReminderEnabled", h.isReminderEnabled)
                put("reminderDays", h.reminderDays)
                put("orderIndex", h.orderIndex)
            }
            habitsArray.put(hObj)
        }
        root.put("habits", habitsArray)

        val logsList = dailyLogDao.getAllLogsList()
        val logsArray = JSONArray()
        for (l in logsList) {
            val lObj = JSONObject().apply {
                put("date", l.date)
                put("habitId", l.habitId)
                put("completed", l.completed)
                put("updatedAt", l.updatedAt)
            }
            logsArray.put(lObj)
        }
        root.put("logs", logsArray)

        root.toString(2)
    }

    suspend fun importDataFromJson(jsonString: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val root = JSONObject(jsonString)
            if (root.has("habits")) {
                val habitsArray = root.getJSONArray("habits")
                for (i in 0 until habitsArray.length()) {
                    val obj = habitsArray.getJSONObject(i)
                    val habit = Habit(
                        id = obj.optLong("id", 0L),
                        name = obj.getString("name"),
                        stat = obj.getString("stat"),
                        frequency = obj.optString("frequency", "daily"),
                        xpPerCheck = obj.optInt("xpPerCheck", 10),
                        isActive = obj.optBoolean("isActive", true),
                        reminderTime = obj.optString("reminderTime", "08:00"),
                        isReminderEnabled = obj.optBoolean("isReminderEnabled", false),
                        reminderDays = obj.optString("reminderDays", "WED,SAT"),
                        orderIndex = obj.optInt("orderIndex", 0)
                    )
                    habitDao.insert(habit)
                }
            }

            if (root.has("logs")) {
                val logsArray = root.getJSONArray("logs")
                for (i in 0 until logsArray.length()) {
                    val obj = logsArray.getJSONObject(i)
                    val log = DailyLog(
                        date = obj.getString("date"),
                        habitId = obj.getLong("habitId"),
                        completed = obj.getBoolean("completed"),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                    dailyLogDao.insertOrUpdate(log)
                }
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    suspend fun clearAllData() = withContext(Dispatchers.IO) {
        dailyLogDao.clearAll()
        rewardClaimDao.clearAll()
    }
}
