package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.RewardClaim
import kotlinx.coroutines.flow.Flow

@Dao
interface RewardClaimDao {
    @Query("SELECT * FROM reward_claims WHERE date = :date LIMIT 1")
    suspend fun getClaimForDate(date: String): RewardClaim?

    @Query("SELECT * FROM reward_claims WHERE date = :date LIMIT 1")
    fun observeClaimForDate(date: String): Flow<RewardClaim?>

    @Query("SELECT * FROM reward_claims ORDER BY claimedAt DESC")
    fun getAllClaims(): Flow<List<RewardClaim>>

    @Query("SELECT COUNT(*) FROM reward_claims WHERE tierName LIKE '%Tier 3%' AND claimedAt >= :sinceTimestamp")
    suspend fun countTier3ClaimsSince(sinceTimestamp: Long): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(claim: RewardClaim): Long

    @Query("DELETE FROM reward_claims")
    suspend fun clearAll()
}
