package com.example.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "daily_logs",
    indices = [Index(value = ["date", "habitId"], unique = true)]
)
data class DailyLog(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // "YYYY-MM-DD"
    val habitId: Long,
    val completed: Boolean,
    val updatedAt: Long = System.currentTimeMillis()
)
