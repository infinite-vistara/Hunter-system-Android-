package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class Habit(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val stat: String, // STR, VIT, INT, AGI, PER
    val frequency: String = "daily", // "daily" or "2x_week"
    val xpPerCheck: Int = 10,
    val isActive: Boolean = true,
    val reminderTime: String = "08:00",
    val isReminderEnabled: Boolean = false,
    val reminderDays: String = "WED,SAT", // for 2x_week or custom
    val orderIndex: Int = 0
) {
    val statType: StatType
        get() = StatType.fromString(stat)
}
