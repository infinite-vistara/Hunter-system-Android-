package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.RankAColor
import com.example.ui.theme.RankBColor
import com.example.ui.theme.RankCColor
import com.example.ui.theme.RankDColor
import com.example.ui.theme.RankEColor
import com.example.ui.theme.RankNationalColor
import com.example.ui.theme.RankSColor

enum class RankTier(
    val rankCode: String,
    val title: String,
    val minLevel: Int,
    val maxLevel: Int,
    val color: Color,
    val martialFocus: String,
    val mobilityPhase: String,
    val description: String
) {
    E_RANK(
        "E-Rank",
        "Awakened Initiate",
        1,
        10,
        RankEColor,
        "Boxing Fundamentals",
        "Phase 1: Isolation",
        "The foundation of power. Raw potential awaiting refinement."
    ),
    D_RANK(
        "D-Rank",
        "Novice Striker",
        11,
        20,
        RankDColor,
        "Basic Combinations",
        "Phase 2: Differentiation (Early)",
        "Discipline solidifies. Movements become deliberate and clean."
    ),
    C_RANK(
        "C-Rank",
        "Kinetic Adept",
        21,
        30,
        RankCColor,
        "Footwork Integration",
        "Phase 2: Differentiation (Late)",
        "Fluid motion unlocked. Agility and stability synchronize."
    ),
    B_RANK(
        "B-Rank",
        "Combat Specialist",
        31,
        40,
        RankBColor,
        "Power + Muay Thai Intro",
        "Phase 3: Partial Integration (Early)",
        "Destructive force without structural breakdown."
    ),
    A_RANK(
        "A-Rank",
        "Elite Vanguard",
        41,
        50,
        RankAColor,
        "Controlled Live Work",
        "Phase 3: Partial Integration (Late)",
        "Mastery under simulated pressure. Sharp, unflinching control."
    ),
    S_RANK(
        "S-Rank",
        "Monarch's Vanguard",
        51,
        70,
        RankSColor,
        "Adaptive Integration",
        "Phase 4: Full Integration (Early)",
        "Instinct and consciousness merge. Overcoming real stressors."
    ),
    NATIONAL(
        "National Level",
        "National Level Hunter",
        71,
        9999,
        RankNationalColor,
        "Self-Directed Mastery",
        "Phase 4: Full Integration (Mastery)",
        "Transcendent discipline. The system itself bows to your will."
    );

    companion object {
        fun fromLevel(level: Int): RankTier {
            return when {
                level in 1..10 -> E_RANK
                level in 11..20 -> D_RANK
                level in 21..30 -> C_RANK
                level in 31..40 -> B_RANK
                level in 41..50 -> A_RANK
                level in 51..70 -> S_RANK
                else -> NATIONAL
            }
        }
    }
}
