package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reward_claims")
data class RewardClaim(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val date: String, // "YYYY-MM-DD"
    val tierName: String, // "Tier 1 — Spark", "Tier 2 — Momentum", "Tier 3 — Full Clear"
    val rewardText: String,
    val claimedAt: Long = System.currentTimeMillis()
)
