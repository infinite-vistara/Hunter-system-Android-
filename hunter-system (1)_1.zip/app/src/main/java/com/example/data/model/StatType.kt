package com.example.data.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.StatAgi
import com.example.ui.theme.StatInt
import com.example.ui.theme.StatPer
import com.example.ui.theme.StatStr
import com.example.ui.theme.StatVit

enum class StatType(
    val code: String,
    val fullName: String,
    val description: String,
    val color: Color
) {
    STR("STR", "Strength", "Physical power & kinetic force", StatStr),
    VIT("VIT", "Vitality", "Endurance, biological recovery & sleep", StatVit),
    INT("INT", "Intelligence", "Cognitive capacity, deep focus & knowledge", StatInt),
    AGI("AGI", "Agility", "Reaction speed, flow & martial prowess", StatAgi),
    PER("PER", "Perception", "Sensory awareness, impulse control & discipline", StatPer);

    companion object {
        fun fromString(value: String): StatType {
            return entries.firstOrNull { it.code.equals(value, ignoreCase = true) } ?: STR
        }
    }
}
