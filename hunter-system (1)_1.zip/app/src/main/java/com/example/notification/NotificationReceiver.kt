package com.example.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity

class NotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val habitName = intent.getStringExtra(EXTRA_HABIT_NAME) ?: "System Quest"
        val statTag = intent.getStringExtra(EXTRA_STAT_TAG) ?: "DISCIPLINE"
        val customMessage = intent.getStringExtra(EXTRA_MESSAGE)
        val notificationId = intent.getIntExtra(EXTRA_NOTIFICATION_ID, 1001)

        val channelId = CHANNEL_ID
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "System Quests & Disciplines",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Daily quest alerts and system status notifications"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notificationId,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = "[$statTag] $habitName is Due"
        val body = customMessage ?: "$habitName is pending. Keep the streak clean and elevate your rank."

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        try {
            notificationManager.notify(notificationId, builder.build())
        } catch (e: SecurityException) {
            // In case notification permission was revoked
            e.printStackTrace()
        }
    }

    companion object {
        const val CHANNEL_ID = "hunter_system_quests_channel"
        const val EXTRA_HABIT_NAME = "extra_habit_name"
        const val EXTRA_STAT_TAG = "extra_stat_tag"
        const val EXTRA_MESSAGE = "extra_message"
        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"
    }
}
