package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.KeyboardDoubleArrowUp
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RankTier
import com.example.data.model.StatType
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class SparkParticle(
    val angle: Float,
    val speed: Float,
    val size: Float,
    val color: Color
)

@Composable
fun LevelUpOverlay(
    visible: Boolean,
    newLevel: Int,
    rankTier: RankTier,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val shockwaveScale = remember { Animatable(0.2f) }
    val shockwaveAlpha = remember { Animatable(1f) }
    val cardScale = remember { Animatable(0.7f) }
    val glowPulse = remember { Animatable(0.4f) }

    // Pre-calculated spark particles radiating outward
    val particles = remember {
        val colors = listOf(ElectricBlue, SystemCyan, RankSColor, Color(0xFFFFFFFF))
        List(24) {
            val angle = (it * (360f / 24f)) * (Math.PI.toFloat() / 180f)
            SparkParticle(
                angle = angle,
                speed = 80f + (it % 5) * 20f,
                size = 3f + (it % 3) * 1.5f,
                color = colors[it % colors.size]
            )
        }
    }

    LaunchedEffect(visible) {
        if (visible) {
            shockwaveScale.snapTo(0.2f)
            shockwaveAlpha.snapTo(1f)
            cardScale.snapTo(0.75f)

            cardScale.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing)
            )

            shockwaveScale.animateTo(
                targetValue = 2.4f,
                animationSpec = tween(durationMillis = 1200, easing = FastOutSlowInEasing)
            )
            shockwaveAlpha.animateTo(
                targetValue = 0f,
                animationSpec = tween(durationMillis = 1200, easing = LinearEasing)
            )
        }
    }

    LaunchedEffect(visible) {
        if (visible) {
            glowPulse.animateTo(
                targetValue = 1f,
                animationSpec = infiniteRepeatable(
                    animation = tween(750, easing = FastOutSlowInEasing),
                    repeatMode = RepeatMode.Reverse
                )
            )
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(tween(200)) + scaleIn(tween(300)),
        exit = fadeOut(tween(180)) + scaleOut(tween(180))
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xF5060A16))
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null
                ) { onDismiss() },
            contentAlignment = Alignment.Center
        ) {
            // Explosive Shockwave & Arc Sparks Canvas
            Canvas(modifier = Modifier.fillMaxSize()) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.width * 0.35f * shockwaveScale.value

                // Shockwave expanding circle
                drawCircle(
                    color = ElectricBlue.copy(alpha = (shockwaveAlpha.value * 0.4f).coerceIn(0f, 1f)),
                    radius = baseRadius,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                drawCircle(
                    color = SystemCyan.copy(alpha = (shockwaveAlpha.value * 0.2f).coerceIn(0f, 1f)),
                    radius = baseRadius * 0.8f,
                    center = center,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Particle Sparks
                val animFrac = ((shockwaveScale.value - 0.2f) / 2.2f).coerceIn(0f, 1f)
                val pAlpha = shockwaveAlpha.value
                for (p in particles) {
                    val dist = baseRadius * animFrac
                    val px = center.x + cos(p.angle) * dist
                    val py = center.y + sin(p.angle) * dist
                    drawCircle(
                        color = p.color.copy(alpha = (pAlpha * 0.8f).coerceIn(0f, 1f)),
                        radius = p.size.dp.toPx(),
                        center = Offset(px, py)
                    )
                }
            }

            // Central Pulsing Aura Behind Main Window
            Box(
                modifier = Modifier
                    .size(360.dp)
                    .alpha(glowPulse.value * 0.35f)
                    .background(
                        Brush.radialGradient(
                            listOf(ElectricBlue, rankTier.color.copy(alpha = 0.5f), Color.Transparent)
                        ),
                        CircleShape
                    )
            )

            // Main Status Window Dialogue
            Column(
                modifier = Modifier
                    .fillMaxWidth(0.90f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0B1428))
                    .border(
                        BorderStroke(
                            2.dp,
                            Brush.linearGradient(
                                listOf(ElectricBlue, rankTier.color, ElectricBlue)
                            )
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header badge
                Box(
                    modifier = Modifier
                        .background(Color(0x3300D2FF), RoundedCornerShape(4.dp))
                        .border(1.dp, ElectricBlue, RoundedCornerShape(4.dp))
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            tint = ElectricBlue,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SYSTEM AWAKENING PROTOCOL",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.5.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Icon(
                    imageVector = Icons.Default.ElectricBolt,
                    contentDescription = "Awakening Surge",
                    tint = ElectricBlue,
                    modifier = Modifier.size(48.dp)
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "LEVEL UP!",
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 32.sp,
                    letterSpacing = 2.sp
                )

                Text(
                    text = "STATUS WINDOW SYNCHRONIZED",
                    color = SystemCyan,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Level Surge Transition Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF111E38))
                        .border(1.dp, Color(0x664F9DFF), RoundedCornerShape(6.dp))
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "HUNTER PROGRESSION",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "LV. ${if (newLevel > 1) newLevel - 1 else 1}",
                                color = TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 20.sp
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Icon(
                                imageVector = Icons.Default.KeyboardDoubleArrowUp,
                                contentDescription = "Surge",
                                tint = ElectricBlue,
                                modifier = Modifier.size(24.dp)
                            )

                            Spacer(modifier = Modifier.width(10.dp))

                            Text(
                                text = "LV. $newLevel",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 32.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        // Current Rank Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(rankTier.color.copy(alpha = 0.2f))
                                .border(1.dp, rankTier.color, RoundedCornerShape(4.dp))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "${rankTier.rankCode.uppercase()} — ${rankTier.title}",
                                color = rankTier.color,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Stat Surge Row: +1 to all attributes
                Text(
                    text = "ALL ATTRIBUTES SURGED (+5 STAT POINTS)",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    letterSpacing = 0.8.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatType.entries.forEach { stat ->
                        Column(
                            modifier = Modifier
                                .background(Color(0xFF0F1E38), RoundedCornerShape(4.dp))
                                .border(1.dp, stat.color.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 7.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = stat.code,
                                color = stat.color,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "+1",
                                color = Color(0xFF4ADE80),
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "\"${rankTier.description}\"",
                    color = TextSecondary,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 6.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricBlue,
                        contentColor = SystemVoid
                    ),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("dismiss_level_up_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "CLAIM REWARDS & ASCEND",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }
    }
}
