package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearOutSlowInEasing
import androidx.compose.animation.core.keyframes
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RewardClaim
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankAColor
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import kotlin.random.Random

object RewardPools {
    val tier1Spark = listOf(
        "15 min scroll time",
        "3 chocolate squares",
        "4 push-ups then done",
        "5 min walk outside",
        "20 jumping jacks",
        "One topic-roulette spin"
    )

    val tier2Momentum = listOf(
        "30 min scroll time",
        "6 chocolate squares",
        "10 min easy jog",
        "Dance break + 3 chocolate squares",
        "15 min scroll + topic spin",
        "Any light workout + 15 min scroll"
    )

    val tier3FullClear = listOf(
        "45 min scroll time",
        "Full chocolate bar",
        "10 min jog + 20 min scroll",
        "Big treat of choice + topic spin",
        "A full guilt-free hour",
        "Chocolate + scroll + light workout (all three)"
    )

    fun getTierForPct(pct: Float): Pair<String, List<String>?> {
        return when {
            pct < 0.50f -> Pair("No Tier", null)
            pct < 0.75f -> Pair("Tier 1 — Spark", tier1Spark)
            pct < 1.0f -> Pair("Tier 2 — Momentum", tier2Momentum)
            else -> Pair("Tier 3 — Full Clear", tier3FullClear)
        }
    }

    fun pickRewardSeeded(date: String, tierName: String, pool: List<String>): String {
        val seed = (date.hashCode() xor tierName.hashCode()).toLong()
        val rng = Random(seed)
        val index = rng.nextInt(pool.size)
        return pool[index]
    }
}

@Composable
fun LootDropCard(
    date: String,
    dailyPct: Float,
    existingClaim: RewardClaim?,
    tier3ClaimsThisWeek: Int,
    soundEnabled: Boolean,
    onClaimReward: (tierName: String, reward: String) -> Unit,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val (tierName, pool) = RewardPools.getTierForPct(dailyPct)
    val isEligible = pool != null

    val isClaimed = existingClaim != null
    val currentReward = if (isClaimed) {
        existingClaim?.rewardText ?: ""
    } else if (pool != null) {
        RewardPools.pickRewardSeeded(date, tierName, pool)
    } else {
        ""
    }

    // Animation states
    val shakeOffset = remember { Animatable(0f) }
    val flipProgress = remember { Animatable(if (isClaimed) 1f else 0f) }
    var isRevealed by remember { mutableStateOf(isClaimed) }

    LaunchedEffect(isClaimed) {
        if (isClaimed) {
            isRevealed = true
            flipProgress.snapTo(1f)
        }
    }

    fun triggerChestOpen() {
        if (!isEligible || isClaimed || pool == null) return
        scope.launch {
            SystemAudioHelper.playLootRollSound(soundEnabled, scope)
            // Shake chest
            shakeOffset.animateTo(
                targetValue = 0f,
                animationSpec = keyframes {
                    durationMillis = 500
                    -12f at 80
                    12f at 160
                    -10f at 240
                    10f at 320
                    -5f at 400
                    0f at 500
                }
            )
            // Flip card
            flipProgress.animateTo(
                targetValue = 1f,
                animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing)
            )
            isRevealed = true
            onClaimReward(tierName, currentReward)
        }
    }

    SystemWindowPanel(
        modifier = modifier,
        title = "TODAY'S LOOT DROP",
        subtitle = "REWARD ENGINE",
        borderColor = if (dailyPct >= 1.0f) RankSColor else if (dailyPct >= 0.75f) ElectricBlue else BorderElectric
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CURRENT TIER",
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = tierName.uppercase(),
                        color = if (dailyPct >= 1f) RankSColor else if (dailyPct >= 0.75f) ElectricBlue else SystemCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                }

                // Honesty stats tag
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "TIER 3 THIS WEEK",
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "$tier3ClaimsThisWeek claimed",
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 12.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Progress toward next tier bar
            Column(modifier = Modifier.fillMaxWidth()) {
                val nextGoalText = when {
                    dailyPct < 0.5f -> "Need 50% for Tier 1 Spark (${(dailyPct * 100).toInt()}% / 50%)"
                    dailyPct < 0.75f -> "Need 75% for Tier 2 Momentum (${(dailyPct * 100).toInt()}% / 75%)"
                    dailyPct < 1.0f -> "Need 100% for Tier 3 Full Clear (${(dailyPct * 100).toInt()}% / 100%)"
                    else -> "Maximum Tier Unlocked! (100% Complete)"
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = nextGoalText,
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "${(dailyPct * 100).toInt()}%",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                LinearProgressIndicator(
                    progress = { dailyPct.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = if (dailyPct >= 1f) RankSColor else ElectricBlue,
                    trackColor = Color(0xFF131D33)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // The Interactive Loot Box / Reward Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .rotate(shakeOffset.value)
                    .graphicsLayer {
                        rotationY = flipProgress.value * 180f
                        cameraDistance = 12 * density
                    }
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isRevealed) Color(0xFF0F2648) else Color(0xFF111C33)
                    )
                    .border(
                        1.dp,
                        if (isRevealed) ElectricBlue else Color(0x444F9DFF),
                        RoundedCornerShape(6.dp)
                    )
                    .clickable(enabled = isEligible && !isRevealed) { triggerChestOpen() }
                    .padding(14.dp),
                contentAlignment = Alignment.Center
            ) {
                if (flipProgress.value <= 0.5f) {
                    // Front of card / Unopened chest view
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = if (isEligible) Icons.Default.Redeem else Icons.Default.Lock,
                            contentDescription = "Loot Chest",
                            tint = if (isEligible) ElectricBlue else TextMuted,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (isEligible) "LOOT CHEST UNLOCKED • TAP TO OPEN" else "CHEST LOCKED (REACH 50% MINIMUM)",
                            color = if (isEligible) ElectricBlue else TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = if (isEligible) "Seeded single daily roll" else "Complete quests to unlock discipline reward",
                            color = TextMuted,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    // Back of card / Revealed reward view
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .fillMaxWidth()
                            .graphicsLayer { rotationY = 180f } // Counter-rotate so text is upright
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = "Claimed",
                                tint = ElectricBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "SYSTEM REWARD GRANTED",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = currentReward,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = "Daily discipline rewarded • Result locked for today",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
