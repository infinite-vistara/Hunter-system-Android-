package com.example.ui.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.TipsAndUpdates
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.StatVit
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

data class PhysiologicalInsight(
    val title: String,
    val biologicalMechanism: String,
    val cognitiveBenefit: String,
    val actionableCue: String
)

val physiologicalInsights = listOf(
    PhysiologicalInsight(
        title = "Tonic Dopamine vs Phasic Spikes",
        biologicalMechanism = "Completing structured disciplines raises your baseline (tonic) dopamine pool rather than depleting it via cheap passive scrolls.",
        cognitiveBenefit = "Elevates mood, sharpens focus, and eliminates feelings of mid-afternoon apathy or brain fog.",
        actionableCue = "Treat each checkmark as a neurochemical investment in tomorrow morning's drive."
    ),
    PhysiologicalInsight(
        title = "Limbic Friction Override",
        biologicalMechanism = "The anterior cingulate cortex (aMCC) expands physically when you push through resistance to perform challenging tasks.",
        cognitiveBenefit = "Expands willpower reserve: scientists recognize the aMCC as the biological seat of human resilience and longevity.",
        actionableCue = "When resistance feels heaviest, your aMCC is growing the most."
    ),
    PhysiologicalInsight(
        title = "Myelination & Hebb's Law",
        biologicalMechanism = "Repeated firing of neural circuits triggers oligodendrocytes to wrap axons in dense lipid myelin sheaths.",
        cognitiveBenefit = "Increases electrical signal velocity by up to 100x, converting difficult manual discipline into effortless muscle memory.",
        actionableCue = "You aren't just doing a habit—you are physically insulating biological wires in your brain."
    ),
    PhysiologicalInsight(
        title = "BDNF & Synaptogenesis",
        biologicalMechanism = "Physical exertion and cognitive stress upregulate Brain-Derived Neurotrophic Factor (BDNF) in the dentate gyrus.",
        cognitiveBenefit = "Generates fresh neurons, speeds up complex skill acquisition, and shields the nervous system from oxidative degradation.",
        actionableCue = "Physical workouts directly power the mental capacity needed for deep study blocks."
    ),
    PhysiologicalInsight(
        title = "Circadian Cortisol & Melatonin Pulse",
        biologicalMechanism = "Early photon capture by retinal ganglion cells sets an uncompromising 24-hour master clock inside the suprachiasmatic nucleus.",
        cognitiveBenefit = "Sharp morning cortisol wake-up pulse, zero morning grogginess, and precise melatonin release 14–16 hours later.",
        actionableCue = "Never compromise sleep timing—recovery is when your physical and mental stats solidify."
    ),
    PhysiologicalInsight(
        title = "The Winner Effect & Androgen Density",
        biologicalMechanism = "Logging small, consecutive daily victories upregulates androgen receptor density in the ventral tegmental area.",
        cognitiveBenefit = "Increases tolerance for high-stakes pressure and builds unshakeable subconscious self-efficacy.",
        actionableCue = "Small wins compound into predatory focus and supreme calm under pressure."
    )
)

@Composable
fun PhysiologicalMotivationPanel(
    dailyCompletionPct: Float,
    completedCount: Int,
    totalCount: Int,
    modifier: Modifier = Modifier
) {
    var showFullDeepDiveDialog by remember { mutableStateOf(false) }
    var currentInsightIndex by remember { mutableIntStateOf(0) }

    // Dynamic biological state description based on today's progress
    val (statusStageTitle, stageBioText, accentColor) = when {
        dailyCompletionPct == 0f -> Triple(
            "PHASE 0: OVERCOMING LIMBIC INERTIA",
            "Initial friction is strictly physiological: the brain seeks calorie conservation. Confirming your first quest triggers striatal dopamine release and breaks inertia.",
            SystemCyan
        )
        dailyCompletionPct < 0.5f -> Triple(
            "PHASE 1: ACTIVATION ENERGY TRANSCENDED",
            "$completedCount quests confirmed. Basal ganglia circuits are now engaged. Neural resistance drops with each completed task.",
            ElectricBlue
        )
        dailyCompletionPct < 0.75f -> Triple(
            "PHASE 2: PREFRONTAL CORTEX DOMINANCE",
            "Tier 1 unlocked ($completedCount/$totalCount). Executive function has suppressed impulse seeking. Dopamine baseline is actively elevating.",
            StatVit
        )
        dailyCompletionPct < 1.0f -> Triple(
            "PHASE 3: KINETIC MOMENTUM COMPOUNDING",
            "Tier 2 unlocked ($completedCount/$totalCount). You are one step from a full system clear. Anterior midcingulate cortex (aMCC) hypertrophy in progress.",
            RankSColor
        )
        else -> Triple(
            "PHASE 4: SYSTEM CLEAR • NEUROPLASTIC VICTORY",
            "100% protocols locked. All 8 disciplines confirmed. Endogenous dopamine stabilized, physical myelination reinforced, deep sleep priming complete.",
            RankSColor
        )
    }

    val currentInsight = physiologicalInsights[currentInsightIndex]

    SystemWindowPanel(
        modifier = modifier,
        title = "PHYSIOLOGICAL MOTIVATION PROTOCOL",
        subtitle = "NEUROBIOLOGY OF DISCIPLINE",
        borderColor = accentColor
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Icon(
                        imageVector = Icons.Default.Psychology,
                        contentDescription = "Neuroscience",
                        tint = accentColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusStageTitle,
                        color = accentColor,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                TextButton(
                    onClick = { showFullDeepDiveDialog = true },
                    modifier = Modifier.testTag("open_bio_protocols_button")
                ) {
                    Text(
                        text = "DEEP DIVE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = stageBioText,
                color = TextPrimary,
                fontFamily = FontFamily.SansSerif,
                fontSize = 12.sp,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Rotating Science Insight Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0B1426))
                    .border(1.dp, Color(0x334F9DFF), RoundedCornerShape(4.dp))
                    .clickable {
                        currentInsightIndex = (currentInsightIndex + 1) % physiologicalInsights.size
                    }
                    .padding(10.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Science,
                                contentDescription = null,
                                tint = ElectricBlue,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "BIOLOGICAL MECHANISM (TAP TO ROTATE)",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp,
                                letterSpacing = 0.5.sp
                            )
                        }

                        Text(
                            text = "${currentInsightIndex + 1}/${physiologicalInsights.size}",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = currentInsight.title.uppercase(),
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = currentInsight.cognitiveBenefit,
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )
                }
            }
        }
    }

    if (showFullDeepDiveDialog) {
        Dialog(onDismissRequest = { showFullDeepDiveDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0A1224))
                    .border(1.5.dp, ElectricBlue, RoundedCornerShape(8.dp))
                    .padding(18.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "PHYSIOLOGICAL MOTOR",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Text(
                            text = "APEX SCIENCE",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Why daily discipline transforms your biology:\n\n" +
                                "1. aMCC Expansion: The anterior midcingulate cortex expands in volume every time you execute a difficult task you would rather avoid.\n\n" +
                                "2. Dopamine Equilibrium: Real effort maintains a high baseline without receptor downregulation, ending addictive cravings.\n\n" +
                                "3. Cellular Repair: Deep study blocks and physical workouts synchronize circadian rhythms to trigger optimal deep-wave recovery.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        lineHeight = 18.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    TextButton(
                        onClick = { showFullDeepDiveDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text(
                            text = "ACKNOWLEDGE & ADVANCE",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
