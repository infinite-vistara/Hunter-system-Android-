package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StatType
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.TextPrimary
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

private val RADAR_STATS = listOf(StatType.STR, StatType.VIT, StatType.INT, StatType.AGI, StatType.PER)
private val GRID_LEVELS = floatArrayOf(0.25f, 0.5f, 0.75f, 1.0f)
private const val SIDES = 5
private const val ANGLE_OFFSET = -Math.PI / 2

@Composable
fun StatRadarChart(
    modifier: Modifier = Modifier,
    statTotals: Map<StatType, Int>
) {
    val maxStatVal = remember(statTotals) {
        max(10, RADAR_STATS.maxOfOrNull { statTotals[it] ?: 0 } ?: 10)
    }

    val progressAnim = remember { Animatable(1f) }

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(200.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = (size.width / 2f) * 0.78f

                // Draw 4 concentric pentagon grid lines
                for (level in GRID_LEVELS) {
                    val gridPath = Path()
                    val r = radius * level
                    for (i in 0 until SIDES) {
                        val angle = ANGLE_OFFSET + (2 * Math.PI * i / SIDES)
                        val x = (center.x + r * cos(angle)).toFloat()
                        val y = (center.y + r * sin(angle)).toFloat()
                        if (i == 0) gridPath.moveTo(x, y) else gridPath.lineTo(x, y)
                    }
                    gridPath.close()
                    drawPath(
                        path = gridPath,
                        color = Color(0x334F9DFF),
                        style = Stroke(width = 1.dp.toPx())
                    )
                }

                // Draw axis spokes
                for (i in 0 until SIDES) {
                    val angle = ANGLE_OFFSET + (2 * Math.PI * i / SIDES)
                    val x = (center.x + radius * cos(angle)).toFloat()
                    val y = (center.y + radius * sin(angle)).toFloat()
                    drawLine(
                        color = Color(0x224F9DFF),
                        start = center,
                        end = Offset(x, y),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                // Draw filled polygon for current stats
                val dataPath = Path()
                val dataPoints = ArrayList<Offset>(SIDES)
                val animValue = progressAnim.value
                for (i in 0 until SIDES) {
                    val stat = RADAR_STATS[i]
                    val value = statTotals[stat] ?: 0
                    val fraction = if (maxStatVal > 0) {
                        0.15f + 0.85f * ((value.toFloat() / maxStatVal.toFloat()).coerceIn(0f, 1f))
                    } else 0.15f

                    val currentFraction = fraction * animValue
                    val angle = ANGLE_OFFSET + (2 * Math.PI * i / SIDES)
                    val r = (radius * currentFraction).toFloat()
                    val x = (center.x + r * cos(angle)).toFloat()
                    val y = (center.y + r * sin(angle)).toFloat()
                    val point = Offset(x, y)
                    dataPoints.add(point)

                    if (i == 0) dataPath.moveTo(x, y) else dataPath.lineTo(x, y)
                }
                dataPath.close()

                // Polygon fill with subtle gradient
                drawPath(
                    path = dataPath,
                    brush = Brush.radialGradient(
                        colors = listOf(
                            ElectricBlue.copy(alpha = 0.45f),
                            Color(0x2200D2FF)
                        ),
                        center = center,
                        radius = radius
                    ),
                    style = Fill
                )

                // Polygon stroke
                drawPath(
                    path = dataPath,
                    color = ElectricBlue,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Vertices dots with glow halos
                for (i in 0 until dataPoints.size) {
                    val pt = dataPoints[i]
                    val stat = RADAR_STATS[i]
                    drawCircle(
                        color = stat.color.copy(alpha = 0.35f),
                        radius = 5.dp.toPx(),
                        center = pt
                    )
                    drawCircle(
                        color = stat.color,
                        radius = 3.dp.toPx(),
                        center = pt
                    )
                }
            }
        }

        // Stat Badge Cards row below
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            RADAR_STATS.forEach { stat ->
                val points = statTotals[stat] ?: 0
                Column(
                    modifier = Modifier
                        .background(Color(0xFF0F1A30), RoundedCornerShape(4.dp))
                        .border(1.dp, stat.color.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 4.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = stat.code,
                        color = stat.color,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Text(
                        text = "$points",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
