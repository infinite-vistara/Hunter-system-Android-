package com.example.ui.components

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

object SystemAudioHelper {

    private var toneGenerator: ToneGenerator? = null

    init {
        try {
            // STREAM_MUSIC provides reliable playback on all devices and emulators
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 85)
        } catch (e: Exception) {
            try {
                toneGenerator = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 80)
            } catch (e2: Exception) {
                e2.printStackTrace()
            }
        }
    }

    /**
     * Crisp, ultra-low-latency tactical click sound for buttons, tabs, and interactive elements.
     */
    fun playClickSound(soundEnabled: Boolean) {
        if (!soundEnabled) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 35)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Confirmation tone when a single quest is completed.
     */
    fun playQuestCompleteSound(soundEnabled: Boolean) {
        if (!soundEnabled) return
        try {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 120)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    /**
     * Backwards compatibility alias for quest check-in sound.
     */
    fun playCheckInSound(soundEnabled: Boolean) {
        playQuestCompleteSound(soundEnabled)
    }

    /**
     * Triumphant 4-tone victory fanfare when all active daily quests reach 100% completion.
     */
    fun playAllQuestsClearedSound(soundEnabled: Boolean, scope: CoroutineScope) {
        if (!soundEnabled) return
        scope.launch(Dispatchers.Default) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80)
                delay(85)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 100)
                delay(95)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 120)
                delay(115)
                toneGenerator?.startTone(ToneGenerator.TONE_SUP_CONFIRM, 240)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * High-energy ascending chime sequence celebrating streak incrementation or milestone retention.
     */
    fun playStreakCelebrationSound(soundEnabled: Boolean, scope: CoroutineScope) {
        if (!soundEnabled) return
        scope.launch(Dispatchers.Default) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 110)
                delay(105)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 160)
                delay(130)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 220)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Crystalline cryogenic shield sound when Duolingo-style streak freeze stasis activates.
     */
    fun playStreakFreezeSound(soundEnabled: Boolean, scope: CoroutineScope) {
        if (!soundEnabled) return
        scope.launch(Dispatchers.Default) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 90)
                delay(95)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_PRESSHOLDKEY_LITE, 190)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    /**
     * Epic awakening fanfare for leveling up and hunter tier elevation.
     */
    fun playLevelUpSound(soundEnabled: Boolean, scope: CoroutineScope) {
        if (!soundEnabled) return
        scope.launch(Dispatchers.Default) {
            try {
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 100)
                delay(100)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 120)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_HIGH_L, 140)
                delay(140)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 220)
                delay(180)
                toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ALERT_NETWORK_LITE, 300)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun playLootRollSound(soundEnabled: Boolean, scope: CoroutineScope) {
        if (!soundEnabled) return
        scope.launch(Dispatchers.Default) {
            try {
                for (i in 0..4) {
                    toneGenerator?.startTone(ToneGenerator.TONE_CDMA_KEYPAD_VOLUME_KEY_LITE, 40)
                    delay(80)
                }
                delay(60)
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun triggerHapticFeedback(context: Context, hapticEnabled: Boolean) {
        if (!hapticEnabled) return
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vibratorManager?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(35, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(35)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
