package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun CalendarHistoryScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val calendar = remember { Calendar.getInstance() }
    var currentYear by remember { mutableStateOf(calendar.get(Calendar.YEAR)) }
    var currentMonth by remember { mutableStateOf(calendar.get(Calendar.MONTH)) } // 0-based

    var inspectedDate by remember { mutableStateOf(state.selectedDate) }
    var showStasisInfoDialog by remember { mutableStateOf(false) }

    // Month name formatter
    val monthName = remember(currentYear, currentMonth) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        SimpleDateFormat("MMMM yyyy", Locale.US).format(cal.time)
    }

    // Precomputed cells for month grid: list of Pair(dayNumber, dateString) or null
    val monthCells = remember(currentYear, currentMonth) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, currentYear)
            set(Calendar.MONTH, currentMonth)
            set(Calendar.DAY_OF_MONTH, 1)
        }
        val maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
        val firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val leadingBlanks = (firstDayOfWeek - Calendar.SUNDAY + 7) % 7
        val list = ArrayList<Pair<Int, String>?>(42)
        for (i in 0 until leadingBlanks) list.add(null)
        for (d in 1..maxDays) {
            list.add(Pair(d, String.format(Locale.US, "%04d-%02d-%02d", currentYear, currentMonth + 1, d)))
        }
        list
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_calendar")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "SYSTEM ARCHIVE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "HEATMAP & STREAKS",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Streak Metrics Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Current Streak Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SystemCardBg)
                        .border(1.dp, Color(0xFFF97316).copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.LocalFireDepartment,
                                contentDescription = "Current Streak",
                                tint = Color(0xFFF97316),
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "CURRENT",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${state.currentStreak} DAYS",
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Unbroken Discipline",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 10.sp
                        )
                    }
                }

                // Best Streak Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SystemCardBg)
                        .border(1.dp, ElectricBlue.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.WorkspacePremium,
                                contentDescription = "Best Streak",
                                tint = ElectricBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "LONGEST",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${state.longestStreak} DAYS",
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 20.sp
                        )
                        Text(
                            text = "Personal Record",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Streak Freeze / System Stasis Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF0C1B33))
                    .border(1.dp, SystemCyan.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                    .clickable { showStasisInfoDialog = true }
                    .padding(12.dp)
                    .testTag("stasis_card_calendar")
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(4.dp))
                                .background(Color(0x3338BDF8))
                                .border(1.dp, SystemCyan, RoundedCornerShape(4.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("❄️", fontSize = 16.sp)
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "STREAK FREEZE // SYSTEM STASIS",
                                    color = SystemCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }
                            Text(
                                text = "1–2 monthly grace days automatically protect single missed days",
                                color = TextSecondary,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 10.sp
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0x2238BDF8), RoundedCornerShape(4.dp))
                            .border(1.dp, SystemCyan, RoundedCornerShape(4.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${state.freezesAvailableThisMonth} / 2 READY",
                            color = SystemCyan,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // Calendar Heatmap Grid Panel
        item {
            SystemWindowPanel(
                title = "CHRONO HEATMAP",
                subtitle = "COMPLETION DENSITY",
                borderColor = ElectricBlue
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Month Navigator
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (currentMonth == 0) {
                                    currentMonth = 11
                                    currentYear--
                                } else {
                                    currentMonth--
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronLeft,
                                contentDescription = "Prev Month",
                                tint = ElectricBlue
                            )
                        }

                        Text(
                            text = monthName.uppercase(),
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )

                        IconButton(
                            onClick = {
                                if (currentMonth == 11) {
                                    currentMonth = 0
                                    currentYear++
                                } else {
                                    currentMonth++
                                }
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Next Month",
                                tint = ElectricBlue
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Day of week labels (S M T W T F S)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        listOf("S", "M", "T", "W", "T", "F", "S").forEach { dayLabel ->
                            Text(
                                text = dayLabel,
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Month Grid of precomputed cells
                    val rows = remember(monthCells) { monthCells.chunked(7) }

                    for (row in rows) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            for (cell in row) {
                                if (cell == null) {
                                    Spacer(modifier = Modifier.weight(1f))
                                } else {
                                    val dayNum = cell.first
                                    val dayDateStr = cell.second
                                    val isSelected = inspectedDate == dayDateStr
                                    val isToday = state.todayDate == dayDateStr
                                    val isFrozen = state.frozenDates.contains(dayDateStr)

                                    val cellBg = when {
                                        isSelected -> ElectricBlue.copy(alpha = 0.35f)
                                        isFrozen -> Color(0x3338BDF8)
                                        else -> Color(0xFF111E36)
                                    }
                                    val cellBorderColor = when {
                                        isSelected -> ElectricBlue
                                        isFrozen -> SystemCyan
                                        isToday -> SystemCyan
                                        else -> Color(0x334F9DFF)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .aspectRatio(1f)
                                            .padding(2.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(cellBg)
                                            .border(
                                                width = if (isSelected || isFrozen) 1.5.dp else if (isToday) 1.dp else 0.5.dp,
                                                color = cellBorderColor,
                                                shape = RoundedCornerShape(3.dp)
                                            )
                                            .clickable {
                                                inspectedDate = dayDateStr
                                                viewModel.setSelectedDate(dayDateStr)
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = if (isFrozen) "$dayNum❄️" else "$dayNum",
                                            color = when {
                                                isFrozen -> SystemCyan
                                                isToday -> ElectricBlue
                                                else -> TextPrimary
                                            },
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = if (isToday || isSelected || isFrozen) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = if (isFrozen) 9.sp else 11.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .background(Color(0x5538BDF8), RoundedCornerShape(2.dp))
                                    .border(0.5.dp, SystemCyan, RoundedCornerShape(2.dp))
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "❄️ Freeze Protected",
                                color = SystemCyan,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Less",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            listOf(
                                Color(0xFF111E36),
                                Color(0xFF16325C),
                                Color(0xFF1E5296),
                                ElectricBlue
                            ).forEach { color ->
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .background(color, RoundedCornerShape(2.dp))
                                )
                                Spacer(modifier = Modifier.width(3.dp))
                            }
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Full Clear",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }

        // Inspected Day Details
        item {
            SystemWindowPanel(
                title = "DAY BREAKDOWN: $inspectedDate",
                subtitle = "HABIT STATUS",
                borderColor = Color(0x774F9DFF)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val habitMap = state.activeHabits
                    val completedToday = habitMap.count { state.selectedDateLogs[it.id] == true }
                    val isDayFrozen = state.frozenDates.contains(inspectedDate)

                    if (isDayFrozen) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0C2444))
                                .border(1.dp, SystemCyan, RoundedCornerShape(6.dp))
                                .padding(10.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("❄️", fontSize = 16.sp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "SYSTEM STASIS ACTIVE",
                                        color = SystemCyan,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "Duolingo-style grace freeze saved this date! Your unbroken streak was preserved.",
                                        color = TextPrimary,
                                        fontFamily = FontFamily.SansSerif,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Text(
                        text = "$completedToday / ${habitMap.size} COMPLETED ON THIS DATE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    habitMap.forEach { habit ->
                        val isDone = state.selectedDateLogs[habit.id] == true
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isDone) Icons.Default.Check else Icons.Default.Close,
                                contentDescription = null,
                                tint = if (isDone) ElectricBlue else TextMuted,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = habit.name,
                                color = if (isDone) TextPrimary else TextMuted,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 12.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = habit.stat,
                                color = habit.statType.color,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }

        // Weekly / Monthly Recap Summary
        item {
            SystemWindowPanel(
                title = "WEEKLY SYSTEM RECAP",
                subtitle = "APEX REVIEW PROTOCOL",
                borderColor = RankSColor
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "STATUS SUMMARY: ACTIVE CADENCE",
                        color = RankSColor,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "• Active streak: ${state.currentStreak} consecutive days\n• Total disciplines logged: ${state.totalXp / 10} sessions\n• Tier 3 Loot Drops claimed this week: ${state.tier3ClaimsThisWeek}\n• Current Hunter Standing: ${state.rankTier.rankCode} (${state.rankTier.title})",
                        color = TextSecondary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showStasisInfoDialog) {
        Dialog(onDismissRequest = { showStasisInfoDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0D1527))
                    .border(1.5.dp, SystemCyan, RoundedCornerShape(8.dp))
                    .padding(18.dp)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("❄️", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "SYSTEM STASIS // PROTOCOL",
                                    color = SystemCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Duolingo-Style Streak Freeze",
                                    color = TextPrimary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "THE PSYCHOLOGICAL FLAW OF PURE STREAKS:",
                        color = Color(0xFFF97316),
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Traditional habit apps demand all-or-nothing streaks. Behavioral psychologists call the aftermath the 'Abstinence Violation Effect': when someone who has a 45-day streak misses a single day due to illness or family emergency, they feel intense failure and quit completely.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "HOW DUOLINGO & HUNTER SYSTEM FIX IT:",
                        color = SystemCyan,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "You are equipped with 1–2 monthly grace days (Streak Freezes). If life forces an unexpected rest day, System Stasis absorbs the gap, locking your streak in ice rather than resetting to zero.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF081226))
                            .border(1.dp, BorderElectric, RoundedCornerShape(6.dp))
                            .padding(10.dp)
                    ) {
                        Column {
                            Text(
                                text = "CURRENT MONTH TELEMETRY",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "• Available Freezes: ${state.freezesAvailableThisMonth} / 2\n" +
                                        "• Freezes Deployed: ${state.freezesUsedThisMonth}\n" +
                                        "• Protected Dates: ${if (state.frozenDates.isEmpty()) "None yet (All logged days active)" else state.frozenDates.joinToString(", ")}\n" +
                                        "• Monthly Reset: Refills to 2 on the 1st of each month",
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(
                            onClick = { showStasisInfoDialog = false },
                            modifier = Modifier.testTag("dismiss_stasis_calendar_dialog")
                        ) {
                            Text(
                                text = "CONFIRM & CLOSE",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
