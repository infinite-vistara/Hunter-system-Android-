package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Habit
import com.example.data.model.StatType
import com.example.ui.components.PhysiologicalMotivationPanel
import com.example.ui.components.RewardPools
import com.example.ui.components.StreakFreezePanel
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

@Composable
fun DailyCheckInScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    var showAddDialog by remember { mutableStateOf(false) }
    var habitToEdit by remember { mutableStateOf<Habit?>(null) }

    val completedCount = state.activeHabits.count { state.selectedDateLogs[it.id] == true }
    val totalCount = state.activeHabits.size
    val (tierName, _) = RewardPools.getTierForPct(state.dailyCompletionPct)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // Navigation Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Status Window",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "DAILY QUEST LOG",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "DISCIPLINE CHECK-IN",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Date Switcher Header
        item {
            DateSwitcherBar(
                selectedDate = state.selectedDate,
                todayDate = state.todayDate,
                onDateChange = { viewModel.setSelectedDate(it) }
            )
        }

        // Daily Completion Status Panel
        item {
            SystemWindowPanel(
                title = "QUEST COMPLETION GAUGE",
                subtitle = "LIVE SYNC",
                borderColor = if (state.dailyCompletionPct >= 1f) RankSColor else ElectricBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "$completedCount / $totalCount QUESTS CONFIRMED",
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Redeem,
                                contentDescription = null,
                                tint = if (state.dailyCompletionPct >= 1f) RankSColor else ElectricBlue,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "PROJECTED: $tierName",
                                color = if (state.dailyCompletionPct >= 1f) RankSColor else ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // Circular ring percentage
                    Box(
                        modifier = Modifier.size(56.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(
                            progress = { state.dailyCompletionPct.coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxSize(),
                            color = if (state.dailyCompletionPct >= 1f) RankSColor else ElectricBlue,
                            trackColor = Color(0xFF131D33),
                            strokeWidth = 5.dp
                        )
                        Text(
                            text = "${(state.dailyCompletionPct * 100).toInt()}%",
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Streak Counter & Streak Freeze Panel (Duolingo Resilience Protocol)
        item {
            StreakFreezePanel(
                state = state,
                compact = true
            )
        }

        // Physiological Motivation Protocol Panel
        item {
            PhysiologicalMotivationPanel(
                dailyCompletionPct = state.dailyCompletionPct,
                completedCount = completedCount,
                totalCount = totalCount
            )
        }

        // Section header with add habit button
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE DISCIPLINES (TAP TO COMPLETE)",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                TextButton(
                    onClick = { showAddDialog = true },
                    modifier = Modifier.testTag("add_quest_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Quest",
                        tint = ElectricBlue,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "NEW QUEST",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // The Habit Cards
        items(state.activeHabits, key = { it.id }) { habit ->
            val isCompleted = state.selectedDateLogs[habit.id] == true
            HabitCard(
                habit = habit,
                isCompleted = isCompleted,
                onToggle = { viewModel.toggleHabit(habit.id, isCompleted) },
                onEdit = { habitToEdit = habit }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showAddDialog) {
        HabitEditDialog(
            initialHabit = null,
            onDismiss = { showAddDialog = false },
            onSave = {
                viewModel.saveHabit(it)
                showAddDialog = false
            }
        )
    }

    habitToEdit?.let { habit ->
        HabitEditDialog(
            initialHabit = habit,
            onDismiss = { habitToEdit = null },
            onSave = {
                viewModel.saveHabit(it)
                habitToEdit = null
            },
            onDelete = {
                viewModel.deleteHabit(habit)
                habitToEdit = null
            }
        )
    }
}

@Composable
private fun DateSwitcherBar(
    selectedDate: String,
    todayDate: String,
    onDateChange: (String) -> Unit
) {
    val displayString = remember(selectedDate) {
        try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val displaySdf = SimpleDateFormat("EEEE, MMM d", Locale.US)
            val cal = Calendar.getInstance().apply {
                time = sdf.parse(selectedDate) ?: Calendar.getInstance().time
            }
            displaySdf.format(cal.time)
        } catch (e: Exception) {
            selectedDate
        }
    }

    val isToday = selectedDate == todayDate

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SystemSurfaceVariant)
            .border(1.dp, Color(0x444F9DFF), RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = {
                    try {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val cal = Calendar.getInstance().apply {
                            time = sdf.parse(selectedDate) ?: Calendar.getInstance().time
                            add(Calendar.DAY_OF_YEAR, -1)
                        }
                        onDateChange(sdf.format(cal.time))
                    } catch (e: Exception) {
                        // ignore
                    }
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronLeft,
                    contentDescription = "Previous Day",
                    tint = ElectricBlue
                )
            }

            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = displayString.uppercase(),
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )
                if (isToday) {
                    Text(
                        text = "• TODAY •",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }

            IconButton(
                onClick = {
                    try {
                        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                        val cal = Calendar.getInstance().apply {
                            time = sdf.parse(selectedDate) ?: Calendar.getInstance().time
                            add(Calendar.DAY_OF_YEAR, 1)
                        }
                        onDateChange(sdf.format(cal.time))
                    } catch (e: Exception) {
                        // ignore
                    }
                },
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Next Day",
                    tint = ElectricBlue
                )
            }
        }
    }
}

@Composable
private fun HabitCard(
    habit: Habit,
    isCompleted: Boolean,
    onToggle: () -> Unit,
    onEdit: () -> Unit
) {
    val statType = habit.statType
    val borderColor by animateColorAsState(
        targetValue = if (isCompleted) ElectricBlue else Color(0x334F9DFF),
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "border"
    )
    val cardBgColor by animateColorAsState(
        targetValue = if (isCompleted) Color(0xFF0F2648) else SystemCardBg,
        animationSpec = tween(300, easing = FastOutSlowInEasing),
        label = "bg"
    )

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(cardBgColor)
            .border(1.dp, borderColor, RoundedCornerShape(6.dp))
            .clickable { onToggle() }
            .padding(14.dp)
            .testTag("habit_card_${habit.id}")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Big Confirm Checkbox Area
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(
                        if (isCompleted) ElectricBlue else Color(0xFF141F36)
                    )
                    .border(
                        1.5.dp,
                        if (isCompleted) ElectricBlue else statType.color.copy(alpha = 0.6f),
                        RoundedCornerShape(6.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCompleted) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = "Completed",
                        tint = Color(0xFF070712),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.width(14.dp))

            // Habit Information
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Stat Tag
                    Box(
                        modifier = Modifier
                            .background(statType.color.copy(alpha = 0.2f), RoundedCornerShape(3.dp))
                            .border(1.dp, statType.color, RoundedCornerShape(3.dp))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = statType.code,
                            color = statType.color,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = if (habit.frequency == "2x_week") "2X/WEEK" else "DAILY",
                        color = TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    Text(
                        text = "+${habit.xpPerCheck} XP",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 10.sp
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = habit.name,
                    color = if (isCompleted) TextPrimary else TextSecondary,
                    fontFamily = FontFamily.SansSerif,
                    fontWeight = if (isCompleted) FontWeight.SemiBold else FontWeight.Normal,
                    fontSize = 14.sp,
                    textDecoration = if (isCompleted) TextDecoration.None else null
                )
            }

            // Edit Action Icon
            IconButton(
                onClick = onEdit,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Edit,
                    contentDescription = "Edit Quest",
                    tint = TextMuted,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun HabitEditDialog(
    initialHabit: Habit?,
    onDismiss: () -> Unit,
    onSave: (Habit) -> Unit,
    onDelete: (() -> Unit)? = null
) {
    var name by remember { mutableStateOf(initialHabit?.name ?: "") }
    var selectedStat by remember { mutableStateOf(initialHabit?.stat ?: "STR") }
    var frequency by remember { mutableStateOf(initialHabit?.frequency ?: "daily") }
    var reminderTime by remember { mutableStateOf(initialHabit?.reminderTime ?: "08:00") }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F1A30))
                .border(1.5.dp, ElectricBlue, RoundedCornerShape(8.dp))
                .padding(18.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = if (initialHabit == null) "INITIALIZE NEW QUEST" else "RECALIBRATE QUEST",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Quest Title", color = TextSecondary, fontFamily = FontFamily.Monospace) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = ElectricBlue,
                        unfocusedBorderColor = Color(0x444F9DFF)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "ASSIGN STAT ATTRIBUTE",
                    color = TextMuted,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatType.entries.forEach { stat ->
                        val isSel = selectedStat == stat.code
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSel) stat.color.copy(alpha = 0.3f) else Color(0xFF141F36))
                                .border(1.dp, if (isSel) stat.color else Color(0x334F9DFF), RoundedCornerShape(4.dp))
                                .clickable { selectedStat = stat.code }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = stat.code,
                                color = if (isSel) stat.color else TextSecondary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "CADENCE",
                    color = TextMuted,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CadenceChip(
                        label = "Daily",
                        isSelected = frequency == "daily",
                        onClick = { frequency = "daily" }
                    )
                    CadenceChip(
                        label = "2x / Week",
                        isSelected = frequency == "2x_week",
                        onClick = { frequency = "2x_week" }
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    if (onDelete != null) {
                        TextButton(onClick = onDelete) {
                            Text("DELETE", color = Color(0xFFFF6B6B), fontFamily = FontFamily.Monospace)
                        }
                    }
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
                    }
                    TextButton(
                        onClick = {
                            if (name.isNotBlank()) {
                                onSave(
                                    initialHabit?.copy(
                                        name = name.trim(),
                                        stat = selectedStat,
                                        frequency = frequency,
                                        reminderTime = reminderTime
                                    ) ?: Habit(
                                        name = name.trim(),
                                        stat = selectedStat,
                                        frequency = frequency,
                                        reminderTime = reminderTime
                                    )
                                )
                            }
                        }
                    ) {
                        Text("CONFIRM", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun CadenceChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(if (isSelected) Color(0x3300D2FF) else Color(0xFF141F36))
            .border(1.dp, if (isSelected) ElectricBlue else Color(0x334F9DFF), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) ElectricBlue else TextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp
        )
    }
}
