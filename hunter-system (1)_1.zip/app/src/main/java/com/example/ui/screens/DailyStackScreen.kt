package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.StatVit
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel

data class StackBlock(
    val step: Int,
    val timeLabel: String,
    val title: String,
    val statTag: String,
    val description: String
)

val dailySkeletonSteps = listOf(
    StackBlock(1, "06:30 – 07:00", "Wake & Hydrate", "VIT", "Electrolyte water (500ml) + immediate posture reset"),
    StackBlock(2, "07:00 – 07:30", "Circadian Sunlight Protocol", "VIT", "10–20 min direct AM outdoor light exposure without sunglasses"),
    StackBlock(3, "08:30 – 11:30", "Deep Work Block 1 (Study / College)", "INT", "Single-task focus, phone in locker, 90m ultradian cycles"),
    StackBlock(4, "12:00 – 12:45", "Midday Mobility & Stretch Flow", "STR", "Target hip flexors, thoracic spine, and combat posture balance"),
    StackBlock(5, "14:00 – 17:00", "Deep Work Block 2 (Income / Hustle)", "INT", "High-leverage engineering & revenue execution"),
    StackBlock(6, "18:00 – 19:30", "Physical Training / Martial Arts", "AGI", "Wed & Sat = Boxing/Muay Thai; Other days = active recovery / flow"),
    StackBlock(7, "20:00 – 20:30", "Cold Exposure & Evening Recovery", "VIT", "2–3 min cold shower PM to trigger core drop and dopamine rebound"),
    StackBlock(8, "21:00 – 21:30", "Protein Synthesis Audit", "VIT", "Ensure daily target of Bodyweight(kg) x 1.6g is locked"),
    StackBlock(9, "22:00 – 22:30", "Digital Lockout & Lights Out", "PER", "Zero screen stimulation, blue light cut, 7.5 hrs minimum sleep")
)

@Composable
fun DailyStackScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    var weightInput by remember { mutableStateOf("75") }
    val weightKg = weightInput.toFloatOrNull() ?: 75f
    val proteinTargetG = (weightKg * 1.6f).toInt()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_stack")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "DISCIPLINE ARCHITECTURE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "DAILY STACK GUIDE",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Ordered Daily Skeleton Panel
        item {
            SystemWindowPanel(
                title = "ORDERED DAILY SKELETON",
                subtitle = "OPTIMAL SEQUENCE",
                borderColor = ElectricBlue
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "The chronological template for peak mental clarity and physical conditioning:",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    dailySkeletonSteps.forEach { step ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 5.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .background(Color(0xFF14243F), RoundedCornerShape(4.dp))
                                    .border(1.dp, ElectricBlue, RoundedCornerShape(4.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = "${step.step}",
                                    color = ElectricBlue,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = step.title,
                                        color = TextPrimary,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = step.timeLabel,
                                        color = TextMuted,
                                        fontFamily = FontFamily.Monospace,
                                        fontSize = 10.sp
                                    )
                                }
                                Text(
                                    text = step.description,
                                    color = TextSecondary,
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Weekly Structure Matrix
        item {
            SystemWindowPanel(
                title = "WEEKLY STRUCTURE MATRIX",
                subtitle = "MON — SUN CADENCE",
                borderColor = Color(0xFFFBBF24)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    val days = listOf(
                        Triple("MON", "Standard Deep Stack", "Deep study, income blocks, mobility"),
                        Triple("TUE", "Standard Deep Stack", "Technical college work, study, walk"),
                        Triple("WED", "Martial Arts Practice", "Boxing fundamentals + deep bag work"),
                        Triple("THU", "Standard Deep Stack", "Income creation sprint, stretching"),
                        Triple("FRI", "Standard Deep Stack", "Long study block, review & prep"),
                        Triple("SAT", "Martial Arts Practice", "Muay Thai sparring & combination drills"),
                        Triple("SUN", "Apex Review & Reset", "Weekly summary audit, recovery & mobility")
                    )

                    days.forEach { (day, focus, note) ->
                        val isMartial = focus.contains("Martial")
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .width(36.dp)
                                    .background(
                                        if (isMartial) Color(0xFFFBBF24).copy(alpha = 0.2f) else Color(0xFF141E33),
                                        RoundedCornerShape(3.dp)
                                    )
                                    .border(
                                        1.dp,
                                        if (isMartial) Color(0xFFFBBF24) else Color(0x334F9DFF),
                                        RoundedCornerShape(3.dp)
                                    )
                                    .padding(vertical = 2.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = day,
                                    color = if (isMartial) Color(0xFFFBBF24) else TextSecondary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                )
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = focus,
                                    color = if (isMartial) TextPrimary else TextSecondary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = if (isMartial) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = note,
                                    color = TextMuted,
                                    fontFamily = FontFamily.SansSerif,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // How-To Protocols (Sunlight, Cold Exposure, Protein)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Sunlight
                SystemWindowPanel(
                    title = "SUNLIGHT PROTOCOL (AM)",
                    subtitle = "DOPAMINE & CIRCADIAN RESET",
                    borderColor = Color(0xFFF59E0B)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.LightMode, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("10–20 MIN DIRECT NATURAL LIGHT", color = Color(0xFFF59E0B), fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "View morning outdoor light within 60 minutes of waking. Activates cortisol pulse, calibrates circadian master clock (SCN), and primes melatonin onset 14–16 hours later for effortless deep sleep.",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp
                        )
                    }
                }

                // Cold Exposure
                SystemWindowPanel(
                    title = "COLD EXPOSURE PROTOCOL (PM)",
                    subtitle = "NOREPINEPHRINE & RECOVERY",
                    borderColor = SystemCyan
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.AcUnit, contentDescription = null, tint = SystemCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("2–3 MIN UNFLINCHING COLD FINISH", color = SystemCyan, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "End evening shower with cold water. Induces peripheral vasoconstriction followed by core body temperature drop required for REM sleep. Triggers 2.5x dopamine baseline elevation that sustains for hours.",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp
                        )
                    }
                }

                // Protein Calculator
                SystemWindowPanel(
                    title = "PROTEIN TARGET CALCULATOR",
                    subtitle = "BODYWEIGHT × 1.6G PROTOCOL",
                    borderColor = StatVit
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = weightInput,
                                onValueChange = { weightInput = it },
                                label = { Text("Bodyweight (kg)", color = TextSecondary, fontFamily = FontFamily.Monospace) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.weight(1f),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    focusedBorderColor = StatVit,
                                    unfocusedBorderColor = Color(0x444ADE80)
                                )
                            )

                            Spacer(modifier = Modifier.width(14.dp))

                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text("DAILY GOAL", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                                Text(
                                    text = "$proteinTargetG g",
                                    color = StatVit,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 24.sp
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Based on $weightKg kg x 1.6g/kg daily minimum to support hypertrophy, muscular recovery, and cognitive amino acid pools.",
                            color = TextSecondary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
