package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.SportsMartialArts
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RankTier
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel

data class MartialRankNode(
    val rankTier: RankTier,
    val focus: String,
    val keySkills: String,
    val unlockCondition: String
)

val martialCurriculum = listOf(
    MartialRankNode(
        rankTier = RankTier.E_RANK,
        focus = "Boxing Fundamentals",
        keySkills = "Stance, guard, footwork, jab, cross — shadow work only",
        unlockCondition = "10 sessions, zero structural breakdown on video review"
    ),
    MartialRankNode(
        rankTier = RankTier.D_RANK,
        focus = "Basic Combinations",
        keySkills = "Jab-cross, jab-cross-hook, slip, block, light bag work",
        unlockCondition = "Combos stay clean at increasing speed"
    ),
    MartialRankNode(
        rankTier = RankTier.C_RANK,
        focus = "Footwork Integration",
        keySkills = "Combos while moving, angle changes, pivot entries",
        unlockCondition = "Guard holds up while moving across directions"
    ),
    MartialRankNode(
        rankTier = RankTier.B_RANK,
        focus = "Power + Muay Thai Intro",
        keySkills = "Progressive bag power, teep, low roundhouse, basic clinch",
        unlockCondition = "Power delivered without technical decay"
    ),
    MartialRankNode(
        rankTier = RankTier.A_RANK,
        focus = "Controlled Live Work",
        keySkills = "Light technical sparring, knees + elbows introduced",
        unlockCondition = "Clean execution vs live opponent, low intensity"
    ),
    MartialRankNode(
        rankTier = RankTier.S_RANK,
        focus = "Adaptive Integration",
        keySkills = "Full sparring, cognitive stressor mid-round, full clinch dominance",
        unlockCondition = "Solves live contradiction under real combat stress"
    ),
    MartialRankNode(
        rankTier = RankTier.NATIONAL,
        focus = "Self-Directed Mastery",
        keySkills = "Cross-context testing, teaching others, intuitive tactical flow",
        unlockCondition = "Can teach it cleanly and adapt dynamically across arts"
    )
)

@Composable
fun MartialArtsCodexScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val currentLevel = state.level

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_martial")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "RANK-GATED SKILL TREE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "MARTIAL ARTS CODEX",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Summary Card
        item {
            SystemWindowPanel(
                title = "CURRICULUM LADDER",
                subtitle = "BOXING → MUAY THAI",
                borderColor = state.rankTier.color
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "CURRENT COMBAT RANK",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "${state.rankTier.rankCode} // ${state.rankTier.martialFocus}",
                                color = state.rankTier.color,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }

                        Icon(
                            imageVector = Icons.Default.SportsMartialArts,
                            contentDescription = null,
                            tint = state.rankTier.color,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "Practice cadence: 2x/Week (Wed Evening + Sat Morning). Progression unlocks automatically through daily system discipline level-ups.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // The Rank Tree Nodes
        items(martialCurriculum) { node ->
            val isUnlocked = currentLevel >= node.rankTier.minLevel
            val isCurrentRank = state.rankTier == node.rankTier
            MartialRankItem(
                node = node,
                isUnlocked = isUnlocked,
                isCurrentRank = isCurrentRank,
                hunterLevel = currentLevel
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun MartialRankItem(
    node: MartialRankNode,
    isUnlocked: Boolean,
    isCurrentRank: Boolean,
    hunterLevel: Int
) {
    var isExpanded by remember { mutableStateOf(false) }

    val borderColor = when {
        isCurrentRank -> node.rankTier.color
        isUnlocked -> Color(0x664F9DFF)
        else -> Color(0x224F9DFF)
    }

    val bgColor = when {
        isCurrentRank -> Color(0xFF0F2648)
        isUnlocked -> SystemCardBg
        else -> Color(0xFF0A0F1D)
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .border(
                width = if (isCurrentRank) 1.5.dp else 1.dp,
                color = borderColor,
                shape = RoundedCornerShape(6.dp)
            )
            .clickable { isExpanded = !isExpanded }
            .padding(14.dp)
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Status Icon
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isUnlocked) node.rankTier.color.copy(alpha = 0.2f) else Color(0xFF141A29))
                        .border(1.dp, if (isUnlocked) node.rankTier.color else TextMuted, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isUnlocked) {
                        Text(
                            text = node.rankTier.rankCode.take(2),
                            color = node.rankTier.color,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Locked",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${node.rankTier.rankCode} (LV. ${node.rankTier.minLevel}–${if (node.rankTier.maxLevel > 99) "71+" else node.rankTier.maxLevel})",
                            color = if (isUnlocked) node.rankTier.color else TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                        if (isCurrentRank) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Box(
                                modifier = Modifier
                                    .background(ElectricBlue, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "CURRENT",
                                    color = Color(0xFF070712),
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }

                    Text(
                        text = if (isUnlocked) node.focus else "??? LOCKED DISCIPLINE",
                        color = if (isUnlocked) TextPrimary else TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Key Skills Section
            Text(
                text = "KEY DRILLS & SKILLS:",
                color = TextMuted,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp
            )
            Text(
                text = if (isUnlocked) node.keySkills else "Locked until Hunter reaches Level ${node.rankTier.minLevel}. Tap to view tease.",
                color = if (isUnlocked) TextSecondary else TextMuted,
                fontFamily = FontFamily.SansSerif,
                fontSize = 12.sp
            )

            // Unlock Criteria
            if (isUnlocked || isExpanded) {
                Spacer(modifier = Modifier.height(6.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0xFF0B1424), RoundedCornerShape(4.dp))
                        .padding(8.dp)
                ) {
                    Column {
                        Text(
                            text = "MASTERY GATE CRITERION:",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Text(
                            text = node.unlockCondition,
                            color = TextPrimary,
                            fontFamily = FontFamily.SansSerif,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
