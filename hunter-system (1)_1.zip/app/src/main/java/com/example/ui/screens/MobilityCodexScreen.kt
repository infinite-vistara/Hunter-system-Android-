package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SystemAudioHelper
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.StatVit
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel
import kotlinx.coroutines.delay

data class MobilityDrill(
    val targetArea: String,
    val phaseNumber: Int,
    val phaseName: String,
    val minLevel: Int,
    val drillName: String,
    val dose: String,
    val formCue: String
)

val mobilityCurriculum = listOf(
    MobilityDrill(
        targetArea = "Right Leg Load Acceptance",
        phaseNumber = 1,
        phaseName = "Isolation",
        minLevel = 1,
        drillName = "Isometric Wall Sit (Single Leg Bias)",
        dose = "3 sets x 30s hold per side",
        formCue = "Drive through midfoot, knee tracking over second toe, neutral pelvis"
    ),
    MobilityDrill(
        targetArea = "Right Leg Load Acceptance",
        phaseNumber = 2,
        phaseName = "Differentiation",
        minLevel = 11,
        drillName = "Eccentric Bulgarian Split Squats",
        dose = "3 sets x 8 reps (3s descent)",
        formCue = "Maintain vertical torso, keep weight distributed through lead heel and arch"
    ),
    MobilityDrill(
        targetArea = "Right Leg Load Acceptance",
        phaseNumber = 3,
        phaseName = "Partial Integration",
        minLevel = 31,
        drillName = "Drop-to-Stick Landing Drills",
        dose = "4 sets x 5 reps",
        formCue = "Absorb kinetic shock smoothly without knee valgus; quiet landings"
    ),
    MobilityDrill(
        targetArea = "Right Leg Load Acceptance",
        phaseNumber = 4,
        phaseName = "Full Integration",
        minLevel = 51,
        drillName = "Reactive Plyometric Step Bounds into Muay Thai Stance",
        dose = "4 sets x 6 reps per side",
        formCue = "Instant elastic redirection into loaded base, immediate guard set"
    ),

    MobilityDrill(
        targetArea = "Support Leg Stability",
        phaseNumber = 1,
        phaseName = "Isolation",
        minLevel = 1,
        drillName = "Single-Leg Balance Eyes Closed + Toe Taps",
        dose = "3 sets x 45s per foot",
        formCue = "Engage intrinsic foot tripod: heel, first MTP, fifth MTP firmly anchored"
    ),
    MobilityDrill(
        targetArea = "Support Leg Stability",
        phaseNumber = 2,
        phaseName = "Differentiation",
        minLevel = 11,
        drillName = "Single-Leg Romanian Deadlift with Kettlebell",
        dose = "3 sets x 10 reps",
        formCue = "Hinge from hip, square hips to the floor, do not rotate open"
    ),
    MobilityDrill(
        targetArea = "Support Leg Stability",
        phaseNumber = 3,
        phaseName = "Partial Integration",
        minLevel = 31,
        drillName = "Pivot Leg Shadow Boxing (Lead Hook & Cross Pivots)",
        dose = "3 rounds x 2 min",
        formCue = "Rotate on ball of support foot while maintaining posture and center of mass"
    ),
    MobilityDrill(
        targetArea = "Support Leg Stability",
        phaseNumber = 4,
        phaseName = "Full Integration",
        minLevel = 51,
        drillName = "Full Roundhouse Kick Chamber & Hold (Dynamic Retraction)",
        dose = "4 sets x 8 reps per side",
        formCue = "Lock support hip at full internal rotation, zero ankle wobble"
    ),

    MobilityDrill(
        targetArea = "Shoulder & Elbow Instability",
        phaseNumber = 1,
        phaseName = "Isolation",
        minLevel = 1,
        drillName = "Prone Y-T-W Scapular Raises + Band Dislocates",
        dose = "3 sets x 12 reps each",
        formCue = "Initiate motion from scaps, not upper traps; keep neck completely relaxed"
    ),
    MobilityDrill(
        targetArea = "Shoulder & Elbow Instability",
        phaseNumber = 2,
        phaseName = "Differentiation",
        minLevel = 11,
        drillName = "Bottoms-Up Kettlebell Waiter Walk",
        dose = "3 sets x 50 ft per arm",
        formCue = "Elbow at 90 degrees, crush grip on bell, lat engaged"
    ),
    MobilityDrill(
        targetArea = "Shoulder & Elbow Instability",
        phaseNumber = 3,
        phaseName = "Partial Integration",
        minLevel = 31,
        drillName = "Bear Crawl to Pike Push-up Flow",
        dose = "3 sets x 8 smooth transitions",
        formCue = "Push through serratus anterior, upwardly rotate scapula at top"
    ),
    MobilityDrill(
        targetArea = "Shoulder & Elbow Instability",
        phaseNumber = 4,
        phaseName = "Full Integration",
        minLevel = 51,
        drillName = "Heavy Bag Impact Absorptions + Guard Resistance Locks",
        dose = "4 rounds x 2 min",
        formCue = "Maintain rigid forearm framing against resistance without joint compression"
    )
)

data class StretchItem(
    val name: String,
    val durationSec: Int,
    val cue: String
)

val preTrainingDynamicStretches = listOf(
    StretchItem("World's Greatest Stretch Flow", 60, "Deep lunge, forearm to inside heel, thoracic rotation reach"),
    StretchItem("Leg Swings (Front/Back & Lateral)", 45, "Controlled pendulum swing, keeping core braced"),
    StretchItem("Arm Circles & Scapular Hugs", 45, "Progressive diameter, activating rear delts and chest"),
    StretchItem("Hip 90/90 Internal & External Rotations", 60, "Sit tall, rotate knees smoothly side to side without hands")
)

val postTrainingStaticStretches = listOf(
    StretchItem("Deep Couch Stretch (Quad & Hip Flexor)", 90, "Shin flush against wall, tuck pelvis, squeeze glute"),
    StretchItem("Pigeon Pose / Glute Stretch", 90, "Shin parallel to mat, square hips, sink into hip capsule"),
    StretchItem("Child's Pose with Lat Reach", 60, "Walk hands diagonally to stretch lats, breathe deeply"),
    StretchItem("Cross-Body Shoulder & Tricep Stretch", 60, "Pull arm across chest, depress shoulder away from ear")
)

@Composable
fun MobilityCodexScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val hunterLevel = state.level

    // Stretching flow timer state
    var timerRunning by remember { mutableStateOf(false) }
    var timerSecondsRemaining by remember { mutableIntStateOf(60) }
    var timerSelectedLabel by remember { mutableStateOf("World's Greatest Stretch Flow") }

    LaunchedEffect(timerRunning, timerSecondsRemaining) {
        if (timerRunning && timerSecondsRemaining > 0) {
            delay(1000)
            timerSecondsRemaining--
        } else if (timerRunning && timerSecondsRemaining == 0) {
            timerRunning = false
            SystemAudioHelper.playCheckInSound(state.soundEnabled)
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_mobility")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "RECOVERY & REHABILITATION",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "MOBILITY CODEX",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Tabs: 4-Phase Progression vs Daily Stretching Flow
        item {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF0F1A30),
                contentColor = ElectricBlue,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = ElectricBlue
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "4-PHASE PROTOCOL",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "DAILY FLOW & TIMER",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                )
            }
        }

        if (selectedTab == 0) {
            // 4-Phase Progression
            item {
                SystemWindowPanel(
                    title = "TARGETED REHABILITATION",
                    subtitle = "3 ANATOMICAL REGIONS",
                    borderColor = StatVit
                ) {
                    Text(
                        text = "Structured 4-Phase progression: Isolation (Lv 1+) → Differentiation (Lv 11+) → Partial Integration (Lv 31+) → Full Integration (Lv 51+). Tap any drill to inspect technical execution.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp
                    )
                }
            }

            // Group by target area
            val groupedByArea = mobilityCurriculum.groupBy { it.targetArea }
            groupedByArea.forEach { (area, drills) ->
                item {
                    Text(
                        text = area.uppercase(),
                        color = StatVit,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }

                items(drills) { drill ->
                    val isUnlocked = hunterLevel >= drill.minLevel
                    DrillCard(drill = drill, isUnlocked = isUnlocked)
                }
            }
        } else {
            // Daily Stretching Flow + Integrated Timer
            item {
                SystemWindowPanel(
                    title = "STRETCH CHRONOMETER",
                    subtitle = "ACTIVE FLOW",
                    borderColor = ElectricBlue
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = timerSelectedLabel.uppercase(),
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = String.format("%02d:%02d", timerSecondsRemaining / 60, timerSecondsRemaining % 60),
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 38.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { timerRunning = !timerRunning },
                                colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color(0xFF070712)),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (timerRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(if (timerRunning) "PAUSE" else "START", fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = {
                                    timerRunning = false
                                    timerSecondsRemaining = 60
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SystemSurfaceVariant, contentColor = TextPrimary),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("RESET", fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "DYNAMIC PRE-TRAINING FLOW (NON-GATED)",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }

            items(preTrainingDynamicStretches) { stretch ->
                StretchCard(
                    stretch = stretch,
                    onSelectTimer = {
                        timerSelectedLabel = stretch.name
                        timerSecondsRemaining = stretch.durationSec
                        timerRunning = false
                    }
                )
            }

            item {
                Text(
                    text = "STATIC POST-TRAINING FLOW (NON-GATED)",
                    color = StatVit,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            items(postTrainingStaticStretches) { stretch ->
                StretchCard(
                    stretch = stretch,
                    onSelectTimer = {
                        timerSelectedLabel = stretch.name
                        timerSecondsRemaining = stretch.durationSec
                        timerRunning = false
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun DrillCard(drill: MobilityDrill, isUnlocked: Boolean) {
    var expanded by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(if (isUnlocked) SystemCardBg else Color(0xFF090E1A))
            .border(
                1.dp,
                if (isUnlocked) Color(0x554ADE80) else Color(0x224F9DFF),
                RoundedCornerShape(6.dp)
            )
            .clickable { expanded = !expanded }
            .padding(12.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(if (isUnlocked) Color(0x334ADE80) else Color(0xFF141F36), RoundedCornerShape(4.dp))
                        .border(1.dp, if (isUnlocked) StatVit else TextMuted, RoundedCornerShape(4.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    if (isUnlocked) {
                        Text(
                            text = "P${drill.phaseNumber}",
                            color = StatVit,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    } else {
                        Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = TextMuted, modifier = Modifier.size(12.dp))
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "PHASE ${drill.phaseNumber}: ${drill.phaseName.uppercase()} (LV. ${drill.minLevel}+)",
                        color = if (isUnlocked) StatVit else TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Text(
                        text = if (isUnlocked) drill.drillName else "??? UNLOCKS AT LEVEL ${drill.minLevel}",
                        color = if (isUnlocked) TextPrimary else TextMuted,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
            }

            if (isUnlocked || expanded) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "DOSE: ${drill.dose}",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp
                )
                Text(
                    text = "FORM CUE: ${drill.formCue}",
                    color = TextSecondary,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun StretchCard(stretch: StretchItem, onSelectTimer: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SystemCardBg)
            .border(1.dp, Color(0x334F9DFF), RoundedCornerShape(6.dp))
            .clickable { onSelectTimer() }
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = stretch.name,
                    color = TextPrimary,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = stretch.cue,
                    color = TextSecondary,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0F2648))
                    .border(1.dp, ElectricBlue, RoundedCornerShape(4.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "${stretch.durationSec}s",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
        }
    }
}
