package com.example.ui.screens

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessTime
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.model.Habit
import com.example.notification.NotificationScheduler
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankAColor
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemSurfaceVariant
import com.example.ui.theme.SystemVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel
import kotlinx.coroutines.launch

@Composable
fun NotificationsSettingsScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    BackHandler {
        viewModel.navigateBack()
    }

    // Permission launcher for Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "System Alerts Authorized", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "Notifications muted by system permissions", Toast.LENGTH_SHORT).show()
        }
    }

    var showEditNameDialog by remember { mutableStateOf(false) }
    var hunterNameInput by remember { mutableStateOf(state.hunterName) }
    var habitForTimePicker by remember { mutableStateOf<Habit?>(null) }
    var showImportDialog by remember { mutableStateOf(false) }
    var importJsonText by remember { mutableStateOf("") }
    var showResetConfirmDialog by remember { mutableStateOf(false) }

    var eodSummaryEnabled by remember { mutableStateOf(viewModel.isEndOfDaySummaryEnabled()) }
    var eodSummaryTime by remember { mutableStateOf(viewModel.getEndOfDaySummaryTime()) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_settings")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "CONFIGURATION PANEL",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "SETTINGS & ALERTS",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Hunter Identity Configuration
        item {
            SystemWindowPanel(
                title = "HUNTER CREDENTIALS",
                subtitle = "IDENTITY DESIGNATION",
                borderColor = ElectricBlue
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "DESIGNATION",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                        Text(
                            text = state.hunterName,
                            color = TextPrimary,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    Button(
                        onClick = {
                            hunterNameInput = state.hunterName
                            showEditNameDialog = true
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SystemSurfaceVariant, contentColor = ElectricBlue),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text("RENAME", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }

        // Notification Permission Request Card (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0F2648))
                        .border(1.dp, ElectricBlue, RoundedCornerShape(6.dp))
                        .padding(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "SYSTEM ALERT PERMISSION",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "Grant permission so the Hunter System can dispatch scheduled discipline alarms.",
                                color = TextSecondary,
                                fontFamily = FontFamily.SansSerif,
                                fontSize = 11.sp
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) },
                            colors = ButtonDefaults.buttonColors(containerColor = ElectricBlue, contentColor = Color(0xFF070712)),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text("ENABLE", fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // General Audio & Sensory Feedback
        item {
            SystemWindowPanel(
                title = "SENSORY CALIBRATION",
                subtitle = "AUDIO & HAPTICS",
                borderColor = Color(0x664F9DFF)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.VolumeUp, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("System Audio Effects", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                                Text("Check-in chimes, level-up fanfares, loot roll sounds", color = TextMuted, fontSize = 10.sp)
                            }
                        }
                        Switch(
                            checked = state.soundEnabled,
                            onCheckedChange = { viewModel.setSoundEnabled(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue, checkedTrackColor = Color(0xFF0F3460))
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(imageVector = Icons.Default.Vibration, contentDescription = null, tint = ElectricBlue, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Haptic Feedback Pulse", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                                Text("Tactile confirmation when confirming quests", color = TextMuted, fontSize = 10.sp)
                            }
                        }
                        Switch(
                            checked = state.hapticEnabled,
                            onCheckedChange = { viewModel.setHapticEnabled(it) },
                            colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue, checkedTrackColor = Color(0xFF0F3460))
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "SYSTEM AUDIO SYNTHESIS AUDITION",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Real-time acoustic feedback responds dynamically to tactile inputs:",
                        color = TextMuted,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Row of quick sound test chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.playClickSound() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF11223F),
                                contentColor = ElectricBlue
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0x4400D2FF), RoundedCornerShape(4.dp))
                                .testTag("test_click_sound_button")
                        ) {
                            Text("CLICK", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.playQuestCompleteSound() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF11223F),
                                contentColor = ElectricBlue
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0x4400D2FF), RoundedCornerShape(4.dp))
                                .testTag("test_quest_sound_button")
                        ) {
                            Text("QUEST", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.playStreakSound() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF11223F),
                                contentColor = Color(0xFFFFB800)
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0x66FFB800), RoundedCornerShape(4.dp))
                                .testTag("test_streak_sound_button")
                        ) {
                            Text("STREAK", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.playAllQuestsClearedSound() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0F3460),
                                contentColor = ElectricBlue
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0x6600D2FF), RoundedCornerShape(4.dp))
                                .testTag("test_100pct_sound_button")
                        ) {
                            Text("100% CLEARED", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.playStreakFreezeSound() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF0F2648),
                                contentColor = Color(0xFF38BDF8)
                            ),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier
                                .weight(1f)
                                .border(1.dp, Color(0x6638BDF8), RoundedCornerShape(4.dp))
                                .testTag("test_freeze_sound_button")
                        ) {
                            Text("FREEZE SHIELD", fontFamily = FontFamily.Monospace, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = { viewModel.triggerCelebrationPreview() },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF14243F),
                            contentColor = ElectricBlue
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0x6600D2FF), RoundedCornerShape(4.dp))
                            .testTag("preview_level_up_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "PREVIEW LEVEL UP CELEBRATION",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }

        // End-Of-Day Summary Alert
        item {
            SystemWindowPanel(
                title = "END-OF-DAY SUMMARY ALERT",
                subtitle = "COMPLETION RECAP",
                borderColor = SystemCyan
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Daily EOD Audit Notification", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        Text("Triggers at $eodSummaryTime: '5/8 done — still time for the rest'", color = TextMuted, fontSize = 10.sp)
                    }
                    Switch(
                        checked = eodSummaryEnabled,
                        onCheckedChange = {
                            eodSummaryEnabled = it
                            viewModel.toggleEndOfDaySummary(it, eodSummaryTime)
                        },
                        colors = SwitchDefaults.colors(checkedThumbColor = ElectricBlue, checkedTrackColor = Color(0xFF0F3460))
                    )
                }
            }
        }

        // Per-Habit Scheduled Notifications Section
        item {
            Text(
                text = "PER-HABIT SCHEDULED NOTIFICATIONS",
                color = ElectricBlue,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 1.sp
            )
        }

        items(state.allHabits) { habit ->
            HabitNotificationRow(
                habit = habit,
                onToggleReminder = { enabled ->
                    val updated = habit.copy(isReminderEnabled = enabled)
                    viewModel.saveHabit(updated)
                },
                onEditSchedule = {
                    habitForTimePicker = habit
                }
            )
        }

        // Data Management (Local Backup & Export)
        item {
            SystemWindowPanel(
                title = "LOCAL-FIRST STORAGE & BACKUP",
                subtitle = "OFFLINE ARCHIVE",
                borderColor = Color(0xFF4ADE80)
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "100% offline and private. Export your habits and logs to JSON to backup or transfer between devices.",
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val json = viewModel.exportJson()
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Hunter System Backup", json))
                                    Toast.makeText(context, "Backup JSON copied to clipboard!", Toast.LENGTH_LONG).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SystemSurfaceVariant, contentColor = Color(0xFF4ADE80)),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("EXPORT JSON", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }

                        Button(
                            onClick = { showImportDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SystemSurfaceVariant, contentColor = SystemCyan),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("IMPORT JSON", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { showResetConfirmDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF281016), contentColor = RankAColor),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(imageVector = Icons.Default.DeleteForever, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RESET LOGS & PROGRESS", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Rename Dialog
    if (showEditNameDialog) {
        Dialog(onDismissRequest = { showEditNameDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.5.dp, ElectricBlue, RoundedCornerShape(8.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text("RENAME HUNTER DESIGNATION", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = hunterNameInput,
                        onValueChange = { hunterNameInput = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showEditNameDialog = false }) {
                            Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
                        }
                        TextButton(
                            onClick = {
                                viewModel.setHunterName(hunterNameInput)
                                showEditNameDialog = false
                            }
                        ) {
                            Text("SAVE", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Habit Schedule / Time Picker Dialog
    habitForTimePicker?.let { habit ->
        TimeScheduleDialog(
            habit = habit,
            onDismiss = { habitForTimePicker = null },
            onSave = { updatedTime, updatedDays ->
                viewModel.saveHabit(
                    habit.copy(
                        reminderTime = updatedTime,
                        reminderDays = updatedDays,
                        isReminderEnabled = true
                    )
                )
                habitForTimePicker = null
            }
        )
    }

    // Import JSON Dialog
    if (showImportDialog) {
        Dialog(onDismissRequest = { showImportDialog = false }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.5.dp, ElectricBlue, RoundedCornerShape(8.dp))
                    .padding(18.dp)
            ) {
                Column {
                    Text("IMPORT SYSTEM BACKUP", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Paste previously exported JSON archive here:", color = TextSecondary, fontSize = 11.sp)
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = importJsonText,
                        onValueChange = { importJsonText = it },
                        maxLines = 6,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        TextButton(onClick = { showImportDialog = false }) {
                            Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
                        }
                        TextButton(
                            onClick = {
                                scope.launch {
                                    val success = viewModel.importJson(importJsonText)
                                    if (success) {
                                        Toast.makeText(context, "Backup restored successfully!", Toast.LENGTH_SHORT).show()
                                        showImportDialog = false
                                    } else {
                                        Toast.makeText(context, "Invalid JSON structure", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        ) {
                            Text("RESTORE", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // Reset Confirm Dialog
    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("CONFIRM PURGE", color = RankAColor, fontFamily = FontFamily.Monospace) },
            text = { Text("Are you sure you want to clear all completion logs and reset your level to 1?", color = TextSecondary) },
            confirmButton = {
                TextButton(
                    onClick = {
                        scope.launch {
                            viewModel.clearData()
                            showResetConfirmDialog = false
                            Toast.makeText(context, "All logs purged", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("PURGE ALL", color = RankAColor, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) {
                    Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
                }
            },
            containerColor = Color(0xFF0F1A30)
        )
    }
}

@Composable
private fun HabitNotificationRow(
    habit: Habit,
    onToggleReminder: (Boolean) -> Unit,
    onEditSchedule: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(SystemCardBg)
            .border(1.dp, Color(0x334F9DFF), RoundedCornerShape(6.dp))
            .padding(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = habit.name,
                        color = TextPrimary,
                        fontFamily = FontFamily.SansSerif,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Time: ${habit.reminderTime}",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp
                    )
                    if (habit.frequency == "2x_week") {
                        Text(
                            text = " • Days: ${habit.reminderDays}",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            IconButton(onClick = onEditSchedule, modifier = Modifier.size(32.dp)) {
                Icon(
                    imageVector = Icons.Default.AccessTime,
                    contentDescription = "Edit Schedule",
                    tint = ElectricBlue,
                    modifier = Modifier.size(18.dp)
                )
            }

            Spacer(modifier = Modifier.width(6.dp))

            Switch(
                checked = habit.isReminderEnabled,
                onCheckedChange = onToggleReminder,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = ElectricBlue,
                    checkedTrackColor = Color(0xFF0F3460)
                )
            )
        }
    }
}

@Composable
fun TimeScheduleDialog(
    habit: Habit,
    onDismiss: () -> Unit,
    onSave: (time: String, days: String) -> Unit
) {
    var timeInput by remember { mutableStateOf(habit.reminderTime) }
    var selectedDays by remember { mutableStateOf(habit.reminderDays) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFF0F1A30))
                .border(1.5.dp, ElectricBlue, RoundedCornerShape(8.dp))
                .padding(18.dp)
        ) {
            Column {
                Text(
                    text = "SCHEDULE: ${habit.name.take(24)}",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = timeInput,
                    onValueChange = { timeInput = it },
                    label = { Text("Reminder Time (HH:mm)", color = TextSecondary, fontFamily = FontFamily.Monospace) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = ElectricBlue
                    )
                )

                if (habit.frequency == "2x_week") {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("ACTIVE DAYS (COMMA-SEPARATED)", color = TextMuted, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = selectedDays,
                        onValueChange = { selectedDays = it },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = ElectricBlue
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = onDismiss) {
                        Text("CANCEL", color = TextMuted, fontFamily = FontFamily.Monospace)
                    }
                    TextButton(
                        onClick = {
                            onSave(timeInput.trim(), selectedDays.trim())
                        }
                    ) {
                        Text("SAVE SCHEDULE", color = ElectricBlue, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
