package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SelfImprovement
import androidx.compose.material.icons.filled.SportsMartialArts
import androidx.compose.material.icons.filled.ViewAgenda
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LootDropCard
import com.example.ui.components.PhysiologicalMotivationPanel
import com.example.ui.components.StatRadarChart
import com.example.ui.components.StreakFreezePanel
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.BorderElectric
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel

@Composable
fun StatusWindowScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            // System Window Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(ElectricBlue)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "SYSTEM WINDOW // V3.8",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.2.sp
                        )
                    }
                    Text(
                        text = state.hunterName,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 20.sp,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = { viewModel.navigateTo(AppScreen.NOTIFICATIONS_SETTINGS) },
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(SystemSurfaceVariant)
                        .border(1.dp, BorderElectric, RoundedCornerShape(6.dp))
                        .testTag("settings_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Notifications,
                        contentDescription = "Notifications & Settings",
                        tint = ElectricBlue,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // Hunter Identity & Level Card
        item {
            SystemWindowPanel(
                title = "HUNTER CREDENTIALS",
                subtitle = "ACTIVE PROGRESSION",
                borderColor = state.rankTier.color
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "LEVEL",
                                color = TextMuted,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 11.sp
                            )
                            Text(
                                text = "LV. ${state.level}",
                                color = TextPrimary,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 34.sp
                            )
                        }

                        // Rank Badge
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF0A192F))
                                .border(1.5.dp, state.rankTier.color, RoundedCornerShape(6.dp))
                                .padding(horizontal = 14.dp, vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = state.rankTier.rankCode.uppercase(),
                                    color = state.rankTier.color,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 16.sp,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = state.rankTier.title,
                                    color = TextSecondary,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Medium,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // XP Progress Bar
                    val xpFraction = (state.xpInLevel.toFloat() / 500f).coerceIn(0f, 1f)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "XP PROGRESSION",
                            color = TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                        Text(
                            text = "${state.xpInLevel} / 500 XP (${state.xpToNextLevel} TO NEXT)",
                            color = ElectricBlue,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 11.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(Color(0xFF0F1B30))
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(xpFraction)
                                .height(10.dp)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(
                                            SystemCyan,
                                            ElectricBlue,
                                            state.rankTier.color
                                        )
                                    )
                                )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TOTAL SYSTEM XP: ${state.totalXp}",
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "STREAK: ${state.currentStreak}D",
                                color = ElectricBlue,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(Color(0x2238BDF8), RoundedCornerShape(3.dp))
                                    .border(0.8.dp, SystemCyan.copy(alpha = 0.6f), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 5.dp, vertical = 1.5.dp)
                            ) {
                                Text(
                                    text = "❄️ ${state.freezesAvailableThisMonth}/2 SHIELDS",
                                    color = SystemCyan,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Streak & Duolingo-Style Stasis Freeze Shield
        item {
            StreakFreezePanel(state = state)
        }

        // Pentagon Radar Stat Chart
        item {
            SystemWindowPanel(
                title = "STAT CALIBRATION",
                subtitle = "5-AXIS RADAR",
                borderColor = ElectricBlue
            ) {
                StatRadarChart(statTotals = state.statTotals)
            }
        }

        // Today's Loot Drop
        item {
            LootDropCard(
                date = state.todayDate,
                dailyPct = state.dailyCompletionPct,
                existingClaim = state.todayClaim,
                tier3ClaimsThisWeek = state.tier3ClaimsThisWeek,
                soundEnabled = state.soundEnabled,
                onClaimReward = { tier, reward ->
                    viewModel.claimTodayReward(tier, reward)
                }
            )
        }

        // Physiological Motivation Protocol Panel
        item {
            val completedCount = state.activeHabits.count { state.selectedDateLogs[it.id] == true }
            PhysiologicalMotivationPanel(
                dailyCompletionPct = state.dailyCompletionPct,
                completedCount = completedCount,
                totalCount = state.activeHabits.size
            )
        }

        // Quick Link Navigation Grid
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "SYSTEM PROTOCOLS & CODEX",
                    color = ElectricBlue,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 2.dp, bottom = 8.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickNavCard(
                        title = "Daily Quests",
                        subtitle = "${(state.dailyCompletionPct * 100).toInt()}% Done Today",
                        icon = Icons.Default.CheckCircle,
                        accentColor = ElectricBlue,
                        modifier = Modifier.weight(1f),
                        testTag = "nav_daily_checkin",
                        onClick = { viewModel.navigateTo(AppScreen.DAILY_CHECK_IN) }
                    )
                    QuickNavCard(
                        title = "History Log",
                        subtitle = "${state.currentStreak}d Streak Heatmap",
                        icon = Icons.Default.CalendarMonth,
                        accentColor = SystemCyan,
                        modifier = Modifier.weight(1f),
                        testTag = "nav_calendar_history",
                        onClick = { viewModel.navigateTo(AppScreen.CALENDAR_HISTORY) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickNavCard(
                        title = "Martial Codex",
                        subtitle = "${state.rankTier.rankCode} Path",
                        icon = Icons.Default.SportsMartialArts,
                        accentColor = state.rankTier.color,
                        modifier = Modifier.weight(1f),
                        testTag = "nav_martial_codex",
                        onClick = { viewModel.navigateTo(AppScreen.MARTIAL_ARTS_CODEX) }
                    )
                    QuickNavCard(
                        title = "Mobility Codex",
                        subtitle = "4-Phase Recovery",
                        icon = Icons.Default.SelfImprovement,
                        accentColor = Color(0xFF4ADE80),
                        modifier = Modifier.weight(1f),
                        testTag = "nav_mobility_codex",
                        onClick = { viewModel.navigateTo(AppScreen.MOBILITY_CODEX) }
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    QuickNavCard(
                        title = "Daily Stack",
                        subtitle = "Sunlight / Cold / Protein",
                        icon = Icons.Default.ViewAgenda,
                        accentColor = Color(0xFFFBBF24),
                        modifier = Modifier.weight(1f),
                        testTag = "nav_daily_stack",
                        onClick = { viewModel.navigateTo(AppScreen.DAILY_STACK_GUIDE) }
                    )
                    QuickNavCard(
                        title = "Topic Roulette",
                        subtitle = "40-Subject Spin",
                        icon = Icons.Default.HelpOutline,
                        accentColor = Color(0xFFC084FC),
                        modifier = Modifier.weight(1f),
                        testTag = "nav_topic_roulette",
                        onClick = { viewModel.navigateTo(AppScreen.TOPIC_ROULETTE) }
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
private fun QuickNavCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    accentColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(6.dp))
            .background(SystemCardBg)
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(12.dp)
            .testTag(testTag)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(22.dp)
                )
                Box(
                    modifier = Modifier
                        .size(6.dp)
                        .background(accentColor, RoundedCornerShape(1.dp))
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = subtitle,
                color = TextMuted,
                fontFamily = FontFamily.SansSerif,
                fontSize = 11.sp
            )
        }
    }
}
