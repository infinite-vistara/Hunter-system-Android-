package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.TravelExplore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SystemAudioHelper
import com.example.ui.components.SystemWindowPanel
import com.example.ui.theme.ElectricBlue
import com.example.ui.theme.RankSColor
import com.example.ui.theme.SystemBackground
import com.example.ui.theme.SystemCardBg
import com.example.ui.theme.SystemCyan
import com.example.ui.theme.SystemVoid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.HunterUiState
import com.example.ui.viewmodel.HunterViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.random.Random

data class RouletteTopic(
    val category: String,
    val title: String,
    val curiosityPrompt: String
)

val topicPool40 = listOf(
    RouletteTopic("Astronomy", "The James Webb Deep Field & Cosmic Dawn", "How the first galaxies formed just 300 million years after the Big Bang, defying initial galactic models."),
    RouletteTopic("Cryptography", "Zero-Knowledge Proofs & zk-SNARKs", "How you can mathematically prove you possess a secret without revealing even a single bit of information."),
    RouletteTopic("Deep-Sea Biology", "Bioluminescent Abyssal Cephalopods", "How creatures at 4,000 meters produce enzymatic light flashes to camouflage against downwelling photons."),
    RouletteTopic("History", "The Bronze Age Collapse (1200 BCE)", "How interconnected Mediterranean civilizations unraveled simultaneously due to drought, invaders, and trade breakdown."),
    RouletteTopic("Psychology", "The Hyperbolic Discounting Paradox", "Why the human brain prioritizes immediate sub-optimal rewards over massive delayed payoffs, and how to hack it."),
    RouletteTopic("Quantum Physics", "Quantum Entanglement & Non-Locality", "Einstein called it 'spooky action at a distance'—how correlated particles instantaneously coordinate across light-years."),
    RouletteTopic("Stoicism", "Amor Fati & The View From Above", "Marcus Aurelius' mental exercise of zooming into orbit to shrink existential friction into imperceptible dust."),
    RouletteTopic("Neuroscience", "Synaptic Pruning During Deep Sleep", "How the glymphatic system flushes metabolic amyloid waste while microglial cells sever inefficient neural connections."),
    RouletteTopic("Linguistics", "The Proto-Indo-European Root Matrix", "How half the languages spoken on Earth today descend from nomadic steppe pastoralists 6,000 years ago."),
    RouletteTopic("Paleontology", "The Burgess Shale Cambrian Explosion", "When bilateral symmetry, predatory vision, and exoskeletons all emerged within a geological blink of an eye."),
    RouletteTopic("Philosophy", "Gödel's Incompleteness Theorems", "Why every sufficiently complex logical system contains true statements that can never be formally proven."),
    RouletteTopic("Cybernetics", "Norbert Wiener & Feedback Loops", "How steering systems, thermostats, biological homeostasis, and artificial intelligence share identical mathematical laws."),
    RouletteTopic("Game Theory", "The Evolution of Cooperation", "Robert Axelrod's tournaments showing why 'Tit-for-Tat' outlasts purely selfish or purely naive strategies."),
    RouletteTopic("Geology", "The Great Oxidation Event", "How photosynthesizing cyanobacteria 2.4 billion years ago poisoned the anaerobic world and rusted the continents."),
    RouletteTopic("Anthropology", "Dunbar's Number & Tribe Scaling", "Why human neocortex volume mathematically constrains stable social relationships to roughly 150 members."),
    RouletteTopic("Information Theory", "Claude Shannon's Entropy Metric", "Quantifying the irreducible uncertainty of a message and establishing the speed limit of digital communication."),
    RouletteTopic("Mycology", "Mycelial Forest Neural Networks", "How subterranean fungal webs redistribute nitrogen, phosphorus, and electrical danger signals between distant trees."),
    RouletteTopic("Aerospace", "Orbital Slingshots & Lagrange Points", "How Voyager 1 used gravitational resonance from Jupiter and Saturn to escape the sun's gravitational well."),
    RouletteTopic("Complexity Science", "Emergence & Cellular Automata", "Conway's Game of Life: how 4 microscopic rules produce gliders, self-replicating computers, and infinite structures."),
    RouletteTopic("Economics", "The Broken Window Fallacy", "Frédéric Bastiat's demonstration of seen vs unseen consequences in resource destruction and recovery."),
    RouletteTopic("Genetics", "Epigenetic Methylation & Longevity", "How environmental stressors, cold exposure, and fasting physically tag DNA histones to alter cellular age."),
    RouletteTopic("Architecture", "Roman Pozzolanic Concrete", "Why Roman seawalls grow stronger over 2,000 years when seawater reacts with volcanic ash and lime clasts."),
    RouletteTopic("Mythology", "The Hero's Journey & Monomyth", "Joseph Campbell's cross-cultural archetype of the abyss, rebirth, and return with the transformative elixir."),
    RouletteTopic("Biomechanics", "Fascial Elasticity & The Catapult Mechanism", "How human Achilles tendons store and release kinetic energy during running like industrial springs."),
    RouletteTopic("Astrophysics", "Neutron Star Glitches & Magnetars", "Stars the density of an atomic nucleus that rotate hundreds of times per second and generate quadrillion-gauss fields."),
    RouletteTopic("Cognitive Science", "Cognitive Biases: Base Rate Neglect", "Why probabilistic intuition fails when estimating rare events in medical diagnoses and forensic evidence."),
    RouletteTopic("Martial History", "Muay Boran & The Nine Weapons", "Ancient battlefield unarmed combat before glove regulations: knees, elbows, head, fists, and shins as blade weapons."),
    RouletteTopic("Music Theory", "The Harmonic Series & Just Intonation", "Why Pythagorean tuning clashed with equal temperament and gave birth to Western orchestral counterpoint."),
    RouletteTopic("Sociology", "The Matthew Effect in Science & Wealth", "'To those who have, more will be given': cumulative advantage dynamics in citations, networks, and capital."),
    RouletteTopic("Oceanography", "Thermohaline Circulation (AMOC)", "The global conveyor belt driven by Arctic salinity and density differences, regulating the climate of Europe."),
    RouletteTopic("Computer Science", "The Fast Fourier Transform Algorithm", "The top 10 algorithm of the 20th century that turned signal processing from O(N^2) to O(N log N)."),
    RouletteTopic("Evolutionary Biology", "The Red Queen Hypothesis", "'It takes all the running you can do, to keep in the same place': co-evolutionary arms races against parasites."),
    RouletteTopic("Optics", "Wave-Particle Duality & Wheeler's Delayed Choice", "Experiments showing the measurement decision at the back of the apparatus alters the photon's past behavior."),
    RouletteTopic("Materials Science", "Graphene & 2D Metamaterials", "Hexagonal carbon lattices one atom thick with 200 times the tensile strength of steel and ballistic electron flow."),
    RouletteTopic("Archaeology", "Göbekli Tepe & Monumental Enclosures", "11,500-year-old megalithic temple complexes carved before the invention of agriculture, wheels, or pottery."),
    RouletteTopic("Physiology", "Mitochondrial Biogenesis via Zone 2", "How long, slow aerobic output multiplies the cellular powerplants that incinerate lactate and fatty acids."),
    RouletteTopic("Meteorology", "Atmospheric Rivers & Supercells", "Narrow corridors of vapor carrying 15 times the flow of the Mississippi River, feeding severe storm rotating mesocyclones."),
    RouletteTopic("Philosophy of Mind", "The Hard Problem of Consciousness", "Why functional neural calculations should be accompanied by subjective qualia—the feeling of seeing red."),
    RouletteTopic("Robotics", "Inverse Kinematics & Bipedal Stability", "How zero-moment point algorithms enable dynamic bipedal walking over uneven, shifting terrain."),
    RouletteTopic("Cartography", "The Mercator Projection & True Size", "How preserving navigational compass rhumb lines distorts high-latitude continents into deceptive colossal masses.")
)

@Composable
fun TopicRouletteScreen(
    state: HunterUiState,
    viewModel: HunterViewModel,
    modifier: Modifier = Modifier
) {
    BackHandler {
        viewModel.navigateBack()
    }

    val scope = rememberCoroutineScope()
    var selectedIndex by remember { mutableIntStateOf(0) }
    var isSpinning by remember { mutableStateOf(false) }
    val spinRotation = remember { Animatable(0f) }

    fun spinRoulette() {
        if (isSpinning) return
        isSpinning = true
        scope.launch {
            SystemAudioHelper.playLootRollSound(state.soundEnabled, scope)
            // Rapid topic cycle simulation
            for (i in 0..12) {
                selectedIndex = Random.nextInt(topicPool40.size)
                delay(60L + i * 20L)
            }
            spinRotation.snapTo(0f)
            spinRotation.animateTo(
                targetValue = 360f,
                animationSpec = tween(600, easing = FastOutSlowInEasing)
            )
            isSpinning = false
            SystemAudioHelper.triggerHapticFeedback(viewModel.getApplication(), state.hapticEnabled)
        }
    }

    val currentTopic = topicPool40[selectedIndex]

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(SystemBackground)
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateBack() },
                    modifier = Modifier.testTag("back_button_roulette")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = ElectricBlue
                    )
                }
                Spacer(modifier = Modifier.width(4.dp))
                Column {
                    Text(
                        text = "ZERO-COST CURIOSITY ENGINE",
                        color = ElectricBlue,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.2.sp
                    )
                    Text(
                        text = "TOPIC ROULETTE",
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }

        // Info Panel
        item {
            SystemWindowPanel(
                title = "INTELLECTUAL REWARD POOL",
                subtitle = "40 CURATED SUBJECTS",
                borderColor = Color(0xFFC084FC)
            ) {
                Text(
                    text = "A zero-cost reward for deep curiosity. Independent of daily completion rates, spin to discover an obscure concept from astronomy, cryptography, neuroscience, history, or philosophy.",
                    color = TextSecondary,
                    fontFamily = FontFamily.SansSerif,
                    fontSize = 11.sp
                )
            }
        }

        // The Big Spin Wheel / Active Topic Card
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1A30))
                    .border(1.5.dp, Color(0xFFC084FC), RoundedCornerShape(8.dp))
                    .padding(20.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    // Category Badge
                    Box(
                        modifier = Modifier
                            .background(Color(0x33C084FC), RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFFC084FC), RoundedCornerShape(4.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = currentTopic.category.uppercase(),
                            color = Color(0xFFC084FC),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = currentTopic.title,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = currentTopic.curiosityPrompt,
                        color = TextSecondary,
                        fontFamily = FontFamily.SansSerif,
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { spinRoulette() },
                        enabled = !isSpinning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFC084FC),
                            contentColor = SystemVoid
                        ),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier
                            .fillMaxWidth(0.8f)
                            .height(46.dp)
                            .testTag("spin_roulette_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = "Spin",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isSpinning) "CALIBRATING..." else "SPIN ROULETTE",
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
