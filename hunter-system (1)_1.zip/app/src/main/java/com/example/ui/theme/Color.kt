package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// System Window Core Palette
val SystemVoid = Color(0xFF07070F)
val SystemBackground = Color(0xFF0A0A14)
val SystemSurface = Color(0xFF0F172A)
val SystemSurfaceVariant = Color(0xFF16213E)
val SystemSurfaceElevated = Color(0xFF1E293B)
val SystemCardBg = Color(0xE60D1527) // Semi-transparent HUD dark glass

// System Accents
val ElectricBlue = Color(0xFF00D2FF)
val SystemBlue = Color(0xFF4F9DFF)
val SystemCyan = Color(0xFF38BDF8)
val SystemBlueDark = Color(0xFF0F3460)
val GlowBlue = Color(0x6600D2FF)

// Stat Specific Colors
val StatStr = Color(0xFFFF6B6B) // Red
val StatVit = Color(0xFF4ADE80) // Green (#90EE90 / modern vibrant green)
val StatInt = Color(0xFF87CEFA) // Light sky blue
val StatAgi = Color(0xFFFFD580) // Gold
val StatPer = Color(0xFFD8B4FE) // Violet

// Rank Colors
val RankEColor = Color(0xFF94A3B8)
val RankDColor = Color(0xFF2DD4BF)
val RankCColor = Color(0xFF38BDF8)
val RankBColor = Color(0xFFA855F7)
val RankAColor = Color(0xFFEF4444)
val RankSColor = Color(0xFFF59E0B)
val RankNationalColor = Color(0xFF00E5FF)

// Text & Neutral Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val BorderElectric = Color(0x994F9DFF)
val BorderSubtle = Color(0x334F9DFF)
