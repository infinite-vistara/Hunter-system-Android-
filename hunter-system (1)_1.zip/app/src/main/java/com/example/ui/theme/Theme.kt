package com.example.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val SystemColorScheme = darkColorScheme(
    primary = SystemBlue,
    onPrimary = SystemVoid,
    primaryContainer = SystemSurfaceVariant,
    onPrimaryContainer = ElectricBlue,
    secondary = ElectricBlue,
    onSecondary = SystemVoid,
    secondaryContainer = SystemBlueDark,
    onSecondaryContainer = TextPrimary,
    tertiary = SystemCyan,
    onTertiary = SystemVoid,
    background = SystemBackground,
    onBackground = TextPrimary,
    surface = SystemSurface,
    onSurface = TextPrimary,
    surfaceVariant = SystemSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = BorderElectric
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Hunter System is always dark HUD
    dynamicColor: Boolean = false, // Preserve dedicated System Window identity
    content: @Composable () -> Unit
) {
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = SystemBackground.toArgb()
                window.navigationBarColor = SystemBackground.toArgb()
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = SystemColorScheme,
        typography = Typography,
        content = content
    )
}
