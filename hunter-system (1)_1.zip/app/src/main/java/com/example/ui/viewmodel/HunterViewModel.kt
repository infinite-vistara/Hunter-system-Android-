package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.HunterRepository
import com.example.data.model.DailyLog
import com.example.data.model.Habit
import com.example.data.model.RankTier
import com.example.data.model.RewardClaim
import com.example.data.model.StatType
import com.example.notification.NotificationScheduler
import com.example.ui.components.SystemAudioHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppScreen {
    STATUS_WINDOW,
    DAILY_CHECK_IN,
    CALENDAR_HISTORY,
    MARTIAL_ARTS_CODEX,
    MOBILITY_CODEX,
    DAILY_STACK_GUIDE,
    TOPIC_ROULETTE,
    NOTIFICATIONS_SETTINGS
}

data class HunterUiState(
    val hunterName: String = "HUNTER: INDRIS",
    val todayDate: String = "",
    val selectedDate: String = "",
    val activeHabits: List<Habit> = emptyList(),
    val allHabits: List<Habit> = emptyList(),
    val selectedDateLogs: Map<Long, Boolean> = emptyMap(),
    val totalXp: Int = 0,
    val level: Int = 1,
    val rankTier: RankTier = RankTier.E_RANK,
    val xpInLevel: Int = 0,
    val xpToNextLevel: Int = 500,
    val statTotals: Map<StatType, Int> = emptyMap(),
    val dailyCompletionPct: Float = 0f,
    val currentStreak: Int = 0,
    val longestStreak: Int = 0,
    val freezesAvailableThisMonth: Int = 2,
    val freezesUsedThisMonth: Int = 0,
    val frozenDates: Set<String> = emptySet(),
    val todayClaim: RewardClaim? = null,
    val tier3ClaimsThisWeek: Int = 0,
    val soundEnabled: Boolean = true,
    val hapticEnabled: Boolean = true,
    val currentScreen: AppScreen = AppScreen.STATUS_WINDOW,
    val screenStack: List<AppScreen> = listOf(AppScreen.STATUS_WINDOW)
)

class HunterViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs: SharedPreferences = application.getSharedPreferences("hunter_prefs", Context.MODE_PRIVATE)
    private val repository: HunterRepository

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    val todayString: String = dateFormat.format(Date())

    private val _selectedDate = MutableStateFlow(todayString)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _currentScreen = MutableStateFlow(AppScreen.STATUS_WINDOW)
    val currentScreen: StateFlow<AppScreen> = _currentScreen.asStateFlow()

    private val _screenStack = MutableStateFlow(listOf(AppScreen.STATUS_WINDOW))

    private val _levelUpDialog = MutableStateFlow<Pair<Int, RankTier>?>(null)
    val levelUpDialog: StateFlow<Pair<Int, RankTier>?> = _levelUpDialog.asStateFlow()

    private val _hunterName = MutableStateFlow(prefs.getString("hunter_name", "HUNTER: INDRIS") ?: "HUNTER: INDRIS")
    val hunterName = _hunterName.asStateFlow()

    private val _soundEnabled = MutableStateFlow(prefs.getBoolean("sound_enabled", true))
    val soundEnabled = _soundEnabled.asStateFlow()

    private val _hapticEnabled = MutableStateFlow(prefs.getBoolean("haptic_enabled", true))
    val hapticEnabled = _hapticEnabled.asStateFlow()

    private val _tier3Count = MutableStateFlow(0)
    val tier3Count = _tier3Count.asStateFlow()

    private var previousObservedLevel: Int = prefs.getInt("saved_level", 1)

    init {
        val db = AppDatabase.getDatabase(application, viewModelScope)
        repository = HunterRepository(db.habitDao(), db.dailyLogDao(), db.rewardClaimDao())

        viewModelScope.launch(Dispatchers.IO) {
            repository.checkAndSeedInitialHabits()
            refreshTier3Count()
        }
    }

    @OptIn(ExperimentalCoroutinesApi::class)
    private val selectedDateLogsFlow = _selectedDate.flatMapLatest { date ->
        repository.getLogsForDate(date)
    }

    // High performance background computed state
    val uiState: StateFlow<HunterUiState> = combine(
        repository.activeHabits,
        repository.allHabits,
        repository.allCompletedLogs,
        selectedDateLogsFlow,
        _selectedDate
    ) { activeHabits, allHabits, completedLogs, selectedLogs, selDate ->
        computeBaseUiState(activeHabits, allHabits, completedLogs, selectedLogs, selDate)
    }.combine(repository.observeClaimForDate(todayString)) { state, claim ->
        state.copy(todayClaim = claim)
    }.combine(_currentScreen) { state, screen ->
        state.copy(
            currentScreen = screen,
            screenStack = _screenStack.value,
            hunterName = _hunterName.value,
            soundEnabled = _soundEnabled.value,
            hapticEnabled = _hapticEnabled.value,
            tier3ClaimsThisWeek = _tier3Count.value
        )
    }.flowOn(Dispatchers.Default)
    .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = HunterUiState(todayDate = todayString, selectedDate = todayString)
    )

    private fun computeBaseUiState(
        activeHabits: List<Habit>,
        allHabits: List<Habit>,
        completedLogs: List<DailyLog>,
        selectedLogs: List<DailyLog>,
        selDate: String
    ): HunterUiState {
        val totalXp = completedLogs.size * 10
        val level = (totalXp / 500) + 1
        val rank = RankTier.fromLevel(level)
        val xpInLevel = totalXp % 500
        val xpToNextLevel = 500 - xpInLevel

        // Level-up detection
        if (level > previousObservedLevel) {
            previousObservedLevel = level
            prefs.edit().putInt("saved_level", level).apply()
            _levelUpDialog.value = Pair(level, rank)
            SystemAudioHelper.playLevelUpSound(_soundEnabled.value, viewModelScope)
            SystemAudioHelper.triggerHapticFeedback(getApplication(), _hapticEnabled.value)
        } else if (level < previousObservedLevel) {
            previousObservedLevel = level
            prefs.edit().putInt("saved_level", level).apply()
        }

        // Stats totals: map each completed log's habit to its stat
        val habitMap = allHabits.associateBy { it.id }
        val statsMap = mutableMapOf(
            StatType.STR to 0,
            StatType.VIT to 0,
            StatType.INT to 0,
            StatType.AGI to 0,
            StatType.PER to 0
        )
        for (log in completedLogs) {
            val habit = habitMap[log.habitId]
            if (habit != null) {
                val stat = habit.statType
                statsMap[stat] = (statsMap[stat] ?: 0) + 1
            }
        }

        // Selected date logs map & completion percentage
        val logMap = selectedLogs.associate { it.habitId to it.completed }
        val activeCount = activeHabits.size
        val completedCount = activeHabits.count { logMap[it.id] == true }
        val pct = if (activeCount > 0) completedCount.toFloat() / activeCount.toFloat() else 0f

        // High-performance streak computation with 1-2 monthly grace days (Streak Freezes)
        val uniqueActiveDates = completedLogs.map { it.date }.toSet()
        val streakEval = computeStreaksWithFreezes(uniqueActiveDates)

        return HunterUiState(
            hunterName = _hunterName.value,
            todayDate = todayString,
            selectedDate = selDate,
            activeHabits = activeHabits,
            allHabits = allHabits,
            selectedDateLogs = logMap,
            totalXp = totalXp,
            level = level,
            rankTier = rank,
            xpInLevel = xpInLevel,
            xpToNextLevel = xpToNextLevel,
            statTotals = statsMap,
            dailyCompletionPct = pct,
            currentStreak = streakEval.currentStreak,
            longestStreak = streakEval.longestStreak,
            freezesAvailableThisMonth = streakEval.freezesAvailableThisMonth,
            freezesUsedThisMonth = streakEval.freezesUsedThisMonth,
            frozenDates = streakEval.frozenDates,
            soundEnabled = _soundEnabled.value,
            hapticEnabled = _hapticEnabled.value,
            tier3ClaimsThisWeek = _tier3Count.value
        )
    }

    private fun dateToEpochDay(dateStr: String): Long {
        return try {
            val p0 = dateStr.indexOf('-')
            val p1 = dateStr.indexOf('-', p0 + 1)
            if (p0 == -1 || p1 == -1) return 0L
            val y = dateStr.substring(0, p0).toLong()
            val m = dateStr.substring(p0 + 1, p1).toLong()
            val d = dateStr.substring(p1 + 1).toLong()
            val a = (14 - m) / 12
            val y2 = y + 4800 - a
            val m2 = m + 12 * a - 3
            val jdn = d + (153 * m2 + 2) / 5 + 365 * y2 + y2 / 4 - y2 / 100 + y2 / 400 - 32045
            jdn - 2440588L
        } catch (e: Exception) {
            0L
        }
    }

    private val utcDateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
        timeZone = java.util.TimeZone.getTimeZone("UTC")
    }

    private fun epochDayToDateStr(epochDay: Long): String {
        return utcDateFormat.format(Date(epochDay * 86400000L))
    }

    data class StreakEvaluation(
        val currentStreak: Int,
        val longestStreak: Int,
        val frozenDates: Set<String>,
        val freezesUsedThisMonth: Int,
        val freezesAvailableThisMonth: Int
    )

    fun computeStreaksWithFreezes(activeDates: Set<String>): StreakEvaluation {
        if (activeDates.isEmpty()) {
            return StreakEvaluation(0, 0, emptySet(), 0, 2)
        }

        val epochDays = activeDates.map { dateToEpochDay(it) }.filter { it > 0 }.sorted().distinct()
        if (epochDays.isEmpty()) {
            return StreakEvaluation(0, 0, emptySet(), 0, 2)
        }

        val monthlyFreezeCount = mutableMapOf<String, Int>()
        val frozenDates = mutableSetOf<String>()

        var maxStreak = 0
        var currentRunningStreak = 0
        var lastDay: Long? = null

        for (day in epochDays) {
            if (lastDay == null) {
                currentRunningStreak = 1
            } else {
                val diff = day - lastDay
                if (diff == 1L) {
                    currentRunningStreak++
                } else if (diff == 2L) {
                    // Exactly 1 missed day: deploy streak freeze if under 2/month
                    val missedEpoch = lastDay + 1L
                    val missedDateStr = epochDayToDateStr(missedEpoch)
                    val monthKey = missedDateStr.take(7) // "YYYY-MM"
                    val used = monthlyFreezeCount.getOrDefault(monthKey, 0)
                    if (used < 2) {
                        monthlyFreezeCount[monthKey] = used + 1
                        frozenDates.add(missedDateStr)
                        currentRunningStreak += 2
                    } else {
                        currentRunningStreak = 1
                    }
                } else if (diff == 3L) {
                    // 2 consecutive missed days: deploy 2 streak freezes if available
                    val m1Epoch = lastDay + 1L
                    val m2Epoch = lastDay + 2L
                    val m1Str = epochDayToDateStr(m1Epoch)
                    val m2Str = epochDayToDateStr(m2Epoch)
                    val month1 = m1Str.take(7)
                    val month2 = m2Str.take(7)
                    val used1 = monthlyFreezeCount.getOrDefault(month1, 0)
                    val used2 = monthlyFreezeCount.getOrDefault(month2, 0)
                    val canFreezeBoth = if (month1 == month2) {
                        used1 + 2 <= 2
                    } else {
                        used1 < 2 && used2 < 2
                    }
                    if (canFreezeBoth) {
                        if (month1 == month2) {
                            monthlyFreezeCount[month1] = used1 + 2
                        } else {
                            monthlyFreezeCount[month1] = used1 + 1
                            monthlyFreezeCount[month2] = used2 + 1
                        }
                        frozenDates.add(m1Str)
                        frozenDates.add(m2Str)
                        currentRunningStreak += 3
                    } else {
                        currentRunningStreak = 1
                    }
                } else {
                    currentRunningStreak = 1
                }
            }
            if (currentRunningStreak > maxStreak) {
                maxStreak = currentRunningStreak
            }
            lastDay = day
        }

        val todayEpoch = dateToEpochDay(todayString)
        val lastLoggedDay = epochDays.last()
        val currentMonthKey = todayString.take(7)

        val liveStreak = when {
            lastLoggedDay == todayEpoch -> currentRunningStreak
            lastLoggedDay == todayEpoch - 1L -> currentRunningStreak
            lastLoggedDay == todayEpoch - 2L -> {
                // Yesterday was missed: auto-absorb with streak freeze if available
                val yesterdayEpoch = todayEpoch - 1L
                val yesterdayDateStr = epochDayToDateStr(yesterdayEpoch)
                val monthKey = yesterdayDateStr.take(7)
                val used = monthlyFreezeCount.getOrDefault(monthKey, 0)
                if (used < 2) {
                    monthlyFreezeCount[monthKey] = used + 1
                    frozenDates.add(yesterdayDateStr)
                    currentRunningStreak + 1
                } else {
                    0
                }
            }
            lastLoggedDay == todayEpoch - 3L -> {
                // Yesterday and day before yesterday missed: auto-absorb with 2 freezes if available
                val y1Epoch = todayEpoch - 2L
                val y2Epoch = todayEpoch - 1L
                val y1Str = epochDayToDateStr(y1Epoch)
                val y2Str = epochDayToDateStr(y2Epoch)
                val used = monthlyFreezeCount.getOrDefault(currentMonthKey, 0)
                if (used == 0) {
                    monthlyFreezeCount[currentMonthKey] = 2
                    frozenDates.add(y1Str)
                    frozenDates.add(y2Str)
                    currentRunningStreak + 2
                } else {
                    0
                }
            }
            else -> 0
        }

        val currentMonthUsed = monthlyFreezeCount.getOrDefault(currentMonthKey, 0)
        val currentMonthAvailable = (2 - currentMonthUsed).coerceAtLeast(0)

        return StreakEvaluation(
            currentStreak = liveStreak,
            longestStreak = maxOf(maxStreak, liveStreak),
            frozenDates = frozenDates,
            freezesUsedThisMonth = currentMonthUsed,
            freezesAvailableThisMonth = currentMonthAvailable
        )
    }

    fun toggleHabit(habitId: Long, currentCompleted: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            val newStatus = !currentCompleted
            repository.setHabitCompletion(_selectedDate.value, habitId, newStatus)
            if (newStatus) {
                // Check if this completes all active habits or begins/preserves daily streak
                val active = uiState.value.activeHabits
                val currentLogs = uiState.value.selectedDateLogs
                val othersCompleted = active.filter { it.id != habitId }.all { currentLogs[it.id] == true }
                val wasFirstCompleted = active.none { currentLogs[it.id] == true }

                if (othersCompleted && active.isNotEmpty()) {
                    // All daily quests 100% cleared: play 100% fanfare & streak celebration!
                    SystemAudioHelper.playAllQuestsClearedSound(_soundEnabled.value, viewModelScope)
                    SystemAudioHelper.playStreakCelebrationSound(_soundEnabled.value, viewModelScope)
                } else if (wasFirstCompleted) {
                    // First quest of the day checked: activates / extends active streak chain!
                    SystemAudioHelper.playQuestCompleteSound(_soundEnabled.value)
                    SystemAudioHelper.playStreakCelebrationSound(_soundEnabled.value, viewModelScope)
                } else {
                    // Single quest complete tone
                    SystemAudioHelper.playQuestCompleteSound(_soundEnabled.value)
                }
                SystemAudioHelper.triggerHapticFeedback(getApplication(), _hapticEnabled.value)
            } else {
                // Untoggled: subtle click
                SystemAudioHelper.playClickSound(_soundEnabled.value)
                SystemAudioHelper.triggerHapticFeedback(getApplication(), _hapticEnabled.value)
            }
        }
    }

    fun playClickSound() {
        SystemAudioHelper.playClickSound(_soundEnabled.value)
    }

    fun playQuestCompleteSound() {
        SystemAudioHelper.playQuestCompleteSound(_soundEnabled.value)
    }

    fun playStreakSound() {
        SystemAudioHelper.playStreakCelebrationSound(_soundEnabled.value, viewModelScope)
    }

    fun playStreakFreezeSound() {
        SystemAudioHelper.playStreakFreezeSound(_soundEnabled.value, viewModelScope)
    }

    fun playAllQuestsClearedSound() {
        SystemAudioHelper.playAllQuestsClearedSound(_soundEnabled.value, viewModelScope)
    }

    fun setSelectedDate(date: String) {
        if (_selectedDate.value != date) {
            _selectedDate.value = date
            playClickSound()
        }
    }

    fun claimTodayReward(tierName: String, rewardText: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val claim = RewardClaim(
                date = todayString,
                tierName = tierName,
                rewardText = rewardText
            )
            repository.saveRewardClaim(claim)
            refreshTier3Count()
        }
    }

    fun refreshTier3Count() {
        viewModelScope.launch(Dispatchers.IO) {
            _tier3Count.value = repository.countTier3ClaimsThisWeek()
        }
    }

    fun dismissLevelUpDialog() {
        _levelUpDialog.value = null
    }

    fun triggerCelebrationPreview() {
        val currState = uiState.value
        _levelUpDialog.value = Pair(currState.level, currState.rankTier)
        SystemAudioHelper.playLevelUpSound(_soundEnabled.value, viewModelScope)
        SystemAudioHelper.triggerHapticFeedback(getApplication(), _hapticEnabled.value)
    }

    fun navigateTo(screen: AppScreen) {
        if (_currentScreen.value == screen) return
        SystemAudioHelper.playClickSound(_soundEnabled.value)
        SystemAudioHelper.triggerHapticFeedback(getApplication(), _hapticEnabled.value)
        val currentStack = _screenStack.value.toMutableList()
        currentStack.add(screen)
        _screenStack.value = currentStack
        _currentScreen.value = screen
    }

    fun navigateBack(): Boolean {
        SystemAudioHelper.playClickSound(_soundEnabled.value)
        val currentStack = _screenStack.value.toMutableList()
        if (currentStack.size > 1) {
            currentStack.removeAt(currentStack.size - 1)
            _screenStack.value = currentStack
            _currentScreen.value = currentStack.last()
            return true
        }
        return false
    }

    fun setHunterName(name: String) {
        val trimmed = name.trim().ifEmpty { "HUNTER: INDRIS" }
        _hunterName.value = trimmed
        prefs.edit().putString("hunter_name", trimmed).apply()
    }

    fun setSoundEnabled(enabled: Boolean) {
        _soundEnabled.value = enabled
        prefs.edit().putBoolean("sound_enabled", enabled).apply()
    }

    fun setHapticEnabled(enabled: Boolean) {
        _hapticEnabled.value = enabled
        prefs.edit().putBoolean("haptic_enabled", enabled).apply()
    }

    fun saveHabit(habit: Habit) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveHabit(habit)
            if (habit.isReminderEnabled) {
                NotificationScheduler.scheduleHabitReminder(getApplication(), habit)
            } else {
                NotificationScheduler.cancelHabitReminder(getApplication(), habit.id)
            }
        }
    }

    fun deleteHabit(habit: Habit) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteHabit(habit)
            NotificationScheduler.cancelHabitReminder(getApplication(), habit.id)
        }
    }

    fun toggleEndOfDaySummary(enabled: Boolean, time: String) {
        prefs.edit().putBoolean("eod_summary_enabled", enabled).putString("eod_summary_time", time).apply()
        NotificationScheduler.scheduleEndOfDaySummary(getApplication(), time, enabled)
    }

    fun isEndOfDaySummaryEnabled(): Boolean = prefs.getBoolean("eod_summary_enabled", true)
    fun getEndOfDaySummaryTime(): String = prefs.getString("eod_summary_time", "21:30") ?: "21:30"

    suspend fun exportJson(): String = repository.exportDataAsJson()
    suspend fun importJson(json: String): Boolean = repository.importDataFromJson(json)
    suspend fun clearData() = repository.clearAllData()
}
