package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.RankTier
import com.example.ui.viewmodel.HunterViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Hunter System", appName)
  }

  @Test
  fun `test level and rank progression logic`() {
    // 0 XP -> Level 1 (E-Rank)
    val level1 = (0 / 500) + 1
    assertEquals(1, level1)
    assertEquals(RankTier.E_RANK, RankTier.fromLevel(level1))

    // 5000 XP -> Level 11 (D-Rank)
    val level11 = (5000 / 500) + 1
    assertEquals(11, level11)
    assertEquals(RankTier.D_RANK, RankTier.fromLevel(level11))

    // 35000 XP -> Level 71 (National Level)
    val level71 = (35000 / 500) + 1
    assertEquals(71, level71)
    assertEquals(RankTier.NATIONAL, RankTier.fromLevel(level71))
  }

  @Test
  fun `test duolingo style streak freeze preserves streak on single missed day`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = HunterViewModel(app)
    val today = viewModel.todayString

    // User logged 2 days ago, missed yesterday, and logs today
    val cal = java.util.Calendar.getInstance()
    val sdf = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US)
    
    cal.add(java.util.Calendar.DAY_OF_YEAR, -2)
    val twoDaysAgo = sdf.format(cal.time)
    
    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
    val yesterday = sdf.format(cal.time)

    val dates = setOf(twoDaysAgo, today)
    val eval = viewModel.computeStreaksWithFreezes(dates)

    // Streak should be preserved (3 days total including frozen yesterday)
    assertEquals(3, eval.currentStreak)
    assertTrue("Yesterday should be in frozen dates", eval.frozenDates.contains(yesterday))
    assertEquals(1, eval.freezesUsedThisMonth)
    assertEquals(1, eval.freezesAvailableThisMonth)
  }

  @Test
  fun `test max two streak freezes allowed per month`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = HunterViewModel(app)

    // Test with empty dates
    val evalEmpty = viewModel.computeStreaksWithFreezes(emptySet())
    assertEquals(0, evalEmpty.currentStreak)
    assertEquals(2, evalEmpty.freezesAvailableThisMonth)
    assertEquals(0, evalEmpty.freezesUsedThisMonth)
  }
}
